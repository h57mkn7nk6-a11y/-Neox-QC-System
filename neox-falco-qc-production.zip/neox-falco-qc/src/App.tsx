import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useOffline } from '@/hooks/useOffline';
import { useAppStore } from '@/hooks/useStore';
import { usePermission } from '@/hooks/usePermission';
import Layout from '@/components/layout/Layout';
import Login from '@/pages/Login';
import Dashboard from '@/pages/Dashboard';
import SmartEntry from '@/pages/SmartEntry';
import Records from '@/pages/Records';
import RecordDetail from '@/pages/RecordDetail';
import WeeklyDashboard from '@/pages/WeeklyDashboard';
import Reports from '@/pages/Reports';
import Settings from '@/pages/Settings';
import AuditLog from '@/pages/AuditLog';
import WorkOrders from '@/pages/WorkOrders';
import Maintenance from '@/pages/Maintenance';
import Notifications from '@/components/layout/Notifications';

function ProtectedRoute({ children, requiredPerm }: { children: React.ReactNode; requiredPerm?: string }) {
  const { user, loading } = useAuth();
  const hasPerm = usePermission(requiredPerm as any);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-neox-dark">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;
  if (requiredPerm && !hasPerm) return <Navigate to="/" replace />;
  return <>{children}</>;
}

function App() {
  useOffline();
  const { isOnline } = useAppStore();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-neox-dark">
      {!isOnline && (
        <div className="fixed top-0 left-0 right-0 z-50 bg-amber-500 text-white text-center py-1 text-sm font-medium">
          ⚠ OFFLINE MODE — Data will sync when connection is restored
        </div>
      )}
      <Notifications />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/*"
          element={
            <ProtectedRoute>
              <Layout>
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/entry" element={<ProtectedRoute requiredPerm="canAddRecords"><SmartEntry /></ProtectedRoute>} />
                  <Route path="/records" element={<ProtectedRoute requiredPerm="canViewRecords"><Records /></ProtectedRoute>} />
                  <Route path="/records/:id" element={<ProtectedRoute requiredPerm="canViewRecords"><RecordDetail /></ProtectedRoute>} />
                  <Route path="/analytics" element={<ProtectedRoute requiredPerm="canViewAnalytics"><WeeklyDashboard /></ProtectedRoute>} />
                  <Route path="/reports" element={<ProtectedRoute requiredPerm="canViewReports"><Reports /></ProtectedRoute>} />
                  <Route path="/workorders" element={<ProtectedRoute requiredPerm="canManageWorkOrders"><WorkOrders /></ProtectedRoute>} />
                  <Route path="/maintenance" element={<ProtectedRoute requiredPerm="canManageMaintenance"><Maintenance /></ProtectedRoute>} />
                  <Route path="/settings" element={<ProtectedRoute requiredPerm="canManageSettings"><Settings /></ProtectedRoute>} />
                  <Route path="/audit" element={<ProtectedRoute requiredPerm="canViewAuditLog"><AuditLog /></ProtectedRoute>} />
                  <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
              </Layout>
            </ProtectedRoute>
          }
        />
      </Routes>
    </div>
  );
}

export default App;
