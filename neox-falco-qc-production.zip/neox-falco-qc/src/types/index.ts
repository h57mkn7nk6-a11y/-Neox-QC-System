export type UserRole = 'Admin' | 'QC' | 'Production' | 'Maintenance' | 'Warehouse' | 'Viewer';

export interface Technician {
  id: string;
  technician_name: string;
  email: string;
  role: UserRole;
  active: boolean;
  created_at: string;
}

export interface Device {
  id: string;
  device_sn: string;
  model_no: string;
  model_name: string | null;
  active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Model {
  id: string;
  model_no: string;
  model_name: string | null;
  active: boolean;
  created_at: string;
}

export interface DefectLocation {
  id: string;
  location_name: string;
  active: boolean;
  created_at: string;
}

export type RecordStatus = 'PASSED' | 'DEFECTIVE' | 'REPAIR_PENDING' | 'REPAIR_COMPLETED';

export interface ProductionRecord {
  id: string;
  date: string;
  time: string;
  model_id: string | null;
  device_id: string | null;
  device_sn: string;
  status: RecordStatus;
  reason_for_replacement: string | null;
  defect_location_id: string | null;
  photo_before_url: string | null;
  photo_after_url: string | null;
  action_taken: string | null;
  wo_number: string | null;
  technician_id: string | null;
  created_at: string;
  updated_at: string;
  model?: Model;
  defect_location?: DefectLocation;
  technician?: Technician;
}

export interface Defect {
  id: string;
  production_record_id: string;
  device_id: string | null;
  defect_type: string;
  defect_location_id: string | null;
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  description: string | null;
  technician_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface RecordImage {
  id: string;
  production_record_id: string | null;
  defect_id: string | null;
  image_url: string;
  image_type: 'BEFORE' | 'AFTER' | 'DOCUMENT';
  storage_path: string;
  uploaded_by: string | null;
  created_at: string;
}

export interface WorkOrder {
  id: string;
  wo_number: string;
  device_id: string | null;
  production_record_id: string | null;
  assigned_to: string | null;
  status: 'OPEN' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  priority: 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT';
  description: string | null;
  started_at: string | null;
  completed_at: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface MaintenanceLog {
  id: string;
  work_order_id: string | null;
  device_id: string | null;
  action_taken: string;
  notes: string | null;
  technician_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface AuditLog {
  id: string;
  user_id: string | null;
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'LOGIN' | 'LOGOUT';
  record_id: string | null;
  table_name: string;
  old_value: any;
  new_value: any;
  created_at: string;
  technician?: Technician;
}

export interface DashboardStats {
  totalToday: number;
  passedToday: number;
  defectiveToday: number;
  repairPendingToday: number;
  repairCompletedToday: number;
  defectRate: number;
  weeklyTotal: number;
  weeklyPassed: number;
  weeklyDefective: number;
  weeklyDefectRate: number;
}

export interface DefectLocationStat {
  location_name: string;
  count: number;
}

export interface TechnicianStat {
  technician_name: string;
  count: number;
  passed: number;
  defective: number;
}

export interface DailyTrend {
  date: string;
  total: number;
  passed: number;
  defective: number;
}

export interface OfflineRecord {
  id: string;
  data: Partial<ProductionRecord>;
  photos: { before?: File; after?: File };
  timestamp: number;
  synced: boolean;
}
