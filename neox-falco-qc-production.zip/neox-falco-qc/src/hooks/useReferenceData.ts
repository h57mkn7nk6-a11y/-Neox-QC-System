import { useState, useCallback, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Model, DefectLocation, Technician } from '@/types';
import { useAppStore } from './useStore';

export function useReferenceData() {
  const [models, setModels] = useState<Model[]>([]);
  const [defectLocations, setDefectLocations] = useState<DefectLocation[]>([]);
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [loading, setLoading] = useState(false);
  const { addNotification } = useAppStore();

  const fetchModels = useCallback(async () => {
    const { data, error } = await supabase
      .from('models')
      .select('*')
      .eq('active', true)
      .order('model_no');
    if (error) addNotification(error.message, 'error');
    else setModels(data as Model[] || []);
  }, [addNotification]);

  const fetchDefectLocations = useCallback(async () => {
    const { data, error } = await supabase
      .from('defect_locations')
      .select('*')
      .eq('active', true)
      .order('location_name');
    if (error) addNotification(error.message, 'error');
    else setDefectLocations(data as DefectLocation[] || []);
  }, [addNotification]);

  const fetchTechnicians = useCallback(async () => {
    const { data, error } = await supabase
      .from('technicians')
      .select('*')
      .eq('active', true)
      .order('technician_name');
    if (error) addNotification(error.message, 'error');
    else setTechnicians(data as Technician[] || []);
  }, [addNotification]);

  const createModel = useCallback(async (model: Partial<Model>) => {
    const { data, error } = await supabase.from('models').insert(model).select().single();
    if (error) { addNotification(error.message, 'error'); return null; }
    await fetchModels();
    return data;
  }, [addNotification, fetchModels]);

  const createDefectLocation = useCallback(async (location: Partial<DefectLocation>) => {
    const { data, error } = await supabase.from('defect_locations').insert(location).select().single();
    if (error) { addNotification(error.message, 'error'); return null; }
    await fetchDefectLocations();
    return data;
  }, [addNotification, fetchDefectLocations]);

  useEffect(() => {
    fetchModels();
    fetchDefectLocations();
    fetchTechnicians();
  }, [fetchModels, fetchDefectLocations, fetchTechnicians]);

  return {
    models,
    defectLocations,
    technicians,
    loading,
    fetchModels,
    fetchDefectLocations,
    fetchTechnicians,
    createModel,
    createDefectLocation,
  };
}
