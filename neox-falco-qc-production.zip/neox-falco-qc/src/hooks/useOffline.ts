import { useEffect } from 'react';
import { useAppStore } from './useStore';

export function useOffline() {
  const { isOnline, setIsOnline, addNotification } = useAppStore();

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      addNotification('Connection restored. Syncing data...', 'success');
    };
    const handleOffline = () => {
      setIsOnline(false);
      addNotification('You are offline. Data will be saved locally.', 'warning');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    setIsOnline(navigator.onLine);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [setIsOnline, addNotification]);

  return { isOnline };
}
