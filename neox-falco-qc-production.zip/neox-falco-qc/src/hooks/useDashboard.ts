import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { DashboardStats, DefectLocationStat, TechnicianStat, DailyTrend } from '@/types';
import { getToday, getWeekStart, getWeekEnd, getMonthStart, getMonthEnd, calculateDefectRate } from '@/lib/utils';

export function useDashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [defectLocations, setDefectLocations] = useState<DefectLocationStat[]>([]);
  const [technicianStats, setTechnicianStats] = useState<TechnicianStat[]>([]);
  const [dailyTrend, setDailyTrend] = useState<DailyTrend[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchDashboard = useCallback(async (dateFrom?: string, dateTo?: string) => {
    setLoading(true);
    try {
      const from = dateFrom || getToday();
      const to = dateTo || getToday();

      // Today's stats
      const { data: todayData } = await supabase
        .from('production_records')
        .select('status')
        .eq('date', getToday());

      const todayRecords = todayData || [];
      const passedToday = todayRecords.filter(r => r.status === 'PASSED').length;
      const defectiveToday = todayRecords.filter(r => r.status === 'DEFECTIVE').length;
      const repairPendingToday = todayRecords.filter(r => r.status === 'REPAIR_PENDING').length;
      const repairCompletedToday = todayRecords.filter(r => r.status === 'REPAIR_COMPLETED').length;
      const totalToday = todayRecords.length;

      // Weekly stats
      const { data: weekData } = await supabase
        .from('production_records')
        .select('status')
        .gte('date', getWeekStart())
        .lte('date', getWeekEnd());

      const weekRecords = weekData || [];
      const weeklyPassed = weekRecords.filter(r => r.status === 'PASSED').length;
      const weeklyDefective = weekRecords.filter(r => r.status === 'DEFECTIVE').length;
      const weeklyTotal = weekRecords.length;

      setStats({
        totalToday,
        passedToday,
        defectiveToday,
        repairPendingToday,
        repairCompletedToday,
        defectRate: calculateDefectRate(defectiveToday, totalToday),
        weeklyTotal,
        weeklyPassed,
        weeklyDefective,
        weeklyDefectRate: calculateDefectRate(weeklyDefective, weeklyTotal),
      });

      // Defect locations stats
      const { data: locData } = await supabase
        .from('production_records')
        .select('defect_location_id, defect_location:defect_locations(location_name)')
        .gte('date', from)
        .lte('date', to)
        .not('defect_location_id', 'is', null);

      const locMap = new Map<string, number>();
      (locData || []).forEach((r: any) => {
        const name = r.defect_location?.location_name || 'Unknown';
        locMap.set(name, (locMap.get(name) || 0) + 1);
      });
      setDefectLocations(
        Array.from(locMap.entries())
          .map(([location_name, count]) => ({ location_name, count }))
          .sort((a, b) => b.count - a.count)
      );

      // Technician stats
      const { data: techData } = await supabase
        .from('production_records')
        .select('status, technician:technicians(technician_name)')
        .gte('date', from)
        .lte('date', to);

      const techMap = new Map<string, { count: number; passed: number; defective: number }>();
      (techData || []).forEach((r: any) => {
        const name = r.technician?.technician_name || 'Unknown';
        const existing = techMap.get(name) || { count: 0, passed: 0, defective: 0 };
        existing.count++;
        if (r.status === 'PASSED') existing.passed++;
        if (r.status === 'DEFECTIVE') existing.defective++;
        techMap.set(name, existing);
      });
      setTechnicianStats(
        Array.from(techMap.entries())
          .map(([technician_name, stats]) => ({ technician_name, ...stats }))
          .sort((a, b) => b.count - a.count)
      );

      // Daily trend
      const { data: trendData } = await supabase
        .from('production_records')
        .select('date, status')
        .gte('date', from)
        .lte('date', to)
        .order('date', { ascending: true });

      const trendMap = new Map<string, { total: number; passed: number; defective: number }>();
      (trendData || []).forEach((r: any) => {
        const existing = trendMap.get(r.date) || { total: 0, passed: 0, defective: 0 };
        existing.total++;
        if (r.status === 'PASSED') existing.passed++;
        if (r.status === 'DEFECTIVE') existing.defective++;
        trendMap.set(r.date, existing);
      });
      setDailyTrend(
        Array.from(trendMap.entries()).map(([date, stats]) => ({
          date,
          ...stats,
        }))
      );
    } catch (err) {
      console.error('Dashboard error:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    stats,
    defectLocations,
    technicianStats,
    dailyTrend,
    loading,
    fetchDashboard,
  };
}
