import { useAppStore } from './useStore';
import { ROLE_PERMISSIONS, PermissionKey } from '@/lib/constants';

export function usePermission(permission: PermissionKey): boolean {
  const user = useAppStore((state) => state.user);
  if (!user) return false;
  return ROLE_PERMISSIONS[user.role][permission] ?? false;
}

export function useRole(): string | null {
  const user = useAppStore((state) => state.user);
  return user?.role || null;
}

export function isRoleAtLeast(role: string, minimum: string): boolean {
  const hierarchy = ['Viewer', 'Warehouse', 'Maintenance', 'Production', 'QC', 'Admin'];
  const roleIndex = hierarchy.indexOf(role);
  const minIndex = hierarchy.indexOf(minimum);
  return roleIndex >= minIndex;
}
