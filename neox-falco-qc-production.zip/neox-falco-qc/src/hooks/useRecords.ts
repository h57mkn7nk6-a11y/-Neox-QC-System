import { useState, useCallback, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { ProductionRecord, RecordStatus } from '@/types';
import { useAppStore } from './useStore';

export interface RecordFilters {
  search?: string;
  status?: RecordStatus | 'ALL';
  technicianId?: string;
  defectLocationId?: string;
  dateFrom?: string;
  dateTo?: string;
  modelId?: string;
}

export function useRecords() {
  const [records, setRecords] = useState<ProductionRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [totalCount, setTotalCount] = useState(0);
  const { addNotification } = useAppStore();

  const fetchRecords = useCallback(async (filters: RecordFilters = {}, page = 1, pageSize = 50) => {
    setLoading(true);
    try {
      let query = supabase
        .from('production_records')
        .select('*, model:models(*), defect_location:defect_locations(*), technician:technicians(technician_name)', { count: 'exact' })
        .order('created_at', { ascending: false });

      if (filters.search) {
        query = query.or(`device_sn.ilike.%${filters.search}%,wo_number.ilike.%${filters.search}%`);
      }
      if (filters.status && filters.status !== 'ALL') {
        query = query.eq('status', filters.status);
      }
      if (filters.technicianId) {
        query = query.eq('technician_id', filters.technicianId);
      }
      if (filters.defectLocationId) {
        query = query.eq('defect_location_id', filters.defectLocationId);
      }
      if (filters.dateFrom) {
        query = query.gte('date', filters.dateFrom);
      }
      if (filters.dateTo) {
        query = query.lte('date', filters.dateTo);
      }
      if (filters.modelId) {
        query = query.eq('model_id', filters.modelId);
      }

      const from = (page - 1) * pageSize;
      const to = from + pageSize - 1;
      query = query.range(from, to);

      const { data, error, count } = await query;
      if (error) throw error;

      setRecords(data as ProductionRecord[] || []);
      setTotalCount(count || 0);
    } catch (err: any) {
      addNotification(err.message || 'Failed to fetch records', 'error');
    } finally {
      setLoading(false);
    }
  }, [addNotification]);

  const getRecordById = useCallback(async (id: string): Promise<ProductionRecord | null> => {
    const { data, error } = await supabase
      .from('production_records')
      .select('*, model:models(*), defect_location:defect_locations(*), technician:technicians(technician_name)')
      .eq('id', id)
      .single();
    if (error) {
      addNotification(error.message, 'error');
      return null;
    }
    return data as ProductionRecord;
  }, [addNotification]);

  const checkDuplicateSN = useCallback(async (sn: string, date?: string): Promise<ProductionRecord | null> => {
    const query = supabase
      .from('production_records')
      .select('*, model:models(*), technician:technicians(technician_name)')
      .eq('device_sn', sn)
      .order('created_at', { ascending: false })
      .limit(1);

    if (date) query.eq('date', date);

    const { data, error } = await query.single();
    if (error || !data) return null;
    return data as ProductionRecord;
  }, []);

  const createRecord = useCallback(async (record: Partial<ProductionRecord>): Promise<ProductionRecord | null> => {
    try {
      const { data, error } = await supabase
        .from('production_records')
        .insert(record)
        .select('*, model:models(*), defect_location:defect_locations(*), technician:technicians(technician_name)')
        .single();

      if (error) throw error;
      addNotification('Record saved successfully', 'success');
      return data as ProductionRecord;
    } catch (err: any) {
      addNotification(err.message || 'Failed to save record', 'error');
      return null;
    }
  }, [addNotification]);

  const updateRecord = useCallback(async (id: string, updates: Partial<ProductionRecord>): Promise<boolean> => {
    try {
      const { error } = await supabase
        .from('production_records')
        .update(updates)
        .eq('id', id);

      if (error) throw error;
      addNotification('Record updated successfully', 'success');
      return true;
    } catch (err: any) {
      addNotification(err.message || 'Failed to update record', 'error');
      return false;
    }
  }, [addNotification]);

  const deleteRecord = useCallback(async (id: string): Promise<boolean> => {
    try {
      const { error } = await supabase
        .from('production_records')
        .delete()
        .eq('id', id);

      if (error) throw error;
      addNotification('Record deleted successfully', 'success');
      return true;
    } catch (err: any) {
      addNotification(err.message || 'Failed to delete record', 'error');
      return false;
    }
  }, [addNotification]);

  const generateWONumber = useCallback(async (): Promise<string | null> => {
    try {
      const { data, error } = await supabase.rpc('generate_wo_number');
      if (error) throw error;
      return data as string;
    } catch (err: any) {
      addNotification(err.message || 'Failed to generate WO number', 'error');
      return null;
    }
  }, [addNotification]);

  return {
    records,
    loading,
    totalCount,
    fetchRecords,
    getRecordById,
    checkDuplicateSN,
    createRecord,
    updateRecord,
    deleteRecord,
    generateWONumber,
  };
}
