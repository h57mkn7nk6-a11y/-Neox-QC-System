import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Technician, OfflineRecord } from '@/types';

interface AppState {
  user: Technician | null;
  setUser: (user: Technician | null) => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
  offlineRecords: OfflineRecord[];
  addOfflineRecord: (record: OfflineRecord) => void;
  removeOfflineRecord: (id: string) => void;
  markOfflineSynced: (id: string) => void;
  notifications: Array<{ id: string; message: string; type: 'success' | 'error' | 'warning' | 'info' }>;
  addNotification: (message: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
  removeNotification: (id: string) => void;
  currentPage: string;
  setCurrentPage: (page: string) => void;
  isOnline: boolean;
  setIsOnline: (online: boolean) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      user: null,
      setUser: (user) => set({ user }),
      darkMode: true,
      toggleDarkMode: () => set((state) => ({ darkMode: !state.darkMode })),
      offlineRecords: [],
      addOfflineRecord: (record) =>
        set((state) => ({ offlineRecords: [...state.offlineRecords, record] })),
      removeOfflineRecord: (id) =>
        set((state) => ({ offlineRecords: state.offlineRecords.filter((r) => r.id !== id) })),
      markOfflineSynced: (id) =>
        set((state) => ({
          offlineRecords: state.offlineRecords.map((r) =>
            r.id === id ? { ...r, synced: true } : r
          ),
        })),
      notifications: [],
      addNotification: (message, type = 'info') => {
        const id = crypto.randomUUID();
        set((state) => ({
          notifications: [...state.notifications, { id, message, type }],
        }));
        setTimeout(() => {
          get().removeNotification(id);
        }, 4000);
      },
      removeNotification: (id) =>
        set((state) => ({
          notifications: state.notifications.filter((n) => n.id !== id),
        })),
      currentPage: 'dashboard',
      setCurrentPage: (page) => set({ currentPage: page }),
      isOnline: navigator.onLine,
      setIsOnline: (online) => set({ isOnline: online }),
    }),
    {
      name: 'neox-falco-store',
      partialize: (state) => ({
        darkMode: state.darkMode,
        offlineRecords: state.offlineRecords,
      }),
    }
  )
);
