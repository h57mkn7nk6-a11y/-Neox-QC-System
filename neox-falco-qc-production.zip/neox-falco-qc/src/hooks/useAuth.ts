import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAppStore } from './useStore';
import { Technician } from '@/types';

export function useAuth() {
  const { user, setUser } = useAppStore();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        await fetchTechnician(session.user.id);
      }
      setLoading(false);
    };
    getSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (session?.user) {
        await fetchTechnician(session.user.id);
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, [setUser]);

  const fetchTechnician = async (userId: string) => {
    const { data } = await supabase
      .from('technicians')
      .select('*')
      .eq('id', userId)
      .single();
    if (data) {
      setUser(data as Technician);
    }
  };

  const signIn = useCallback(async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    if (data.user) await fetchTechnician(data.user.id);
    return data;
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setUser(null);
  }, [setUser]);

  const signUp = useCallback(async (email: string, password: string, technicianName: string, role: string = 'Viewer') => {
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) throw error;
    if (data.user) {
      await supabase.from('technicians').insert({
        id: data.user.id,
        technician_name: technicianName,
        email,
        role,
      });
      await fetchTechnician(data.user.id);
    }
    return data;
  }, []);

  return { user, loading, signIn, signOut, signUp };
}
