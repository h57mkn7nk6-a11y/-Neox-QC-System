export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      technicians: {
        Row: {
          id: string;
          technician_name: string;
          email: string;
          role: string;
          active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          technician_name: string;
          email: string;
          role?: string;
          active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          technician_name?: string;
          email?: string;
          role?: string;
          active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      models: {
        Row: {
          id: string;
          model_no: string;
          model_name: string | null;
          active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          model_no: string;
          model_name?: string | null;
          active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          model_no?: string;
          model_name?: string | null;
          active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      defect_locations: {
        Row: {
          id: string;
          location_name: string;
          active: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          location_name: string;
          active?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          location_name?: string;
          active?: boolean;
          created_at?: string;
        };
      };
      production_records: {
        Row: {
          id: string;
          date: string;
          time: string;
          model_id: string | null;
          device_sn: string;
          status: string;
          reason_for_replacement: string | null;
          defect_location_id: string | null;
          photo_before_url: string | null;
          photo_after_url: string | null;
          action_taken: string | null;
          wo_number: string | null;
          technician_id: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          date?: string;
          time?: string;
          model_id?: string | null;
          device_sn: string;
          status: string;
          reason_for_replacement?: string | null;
          defect_location_id?: string | null;
          photo_before_url?: string | null;
          photo_after_url?: string | null;
          action_taken?: string | null;
          wo_number?: string | null;
          technician_id?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          date?: string;
          time?: string;
          model_id?: string | null;
          device_sn?: string;
          status?: string;
          reason_for_replacement?: string | null;
          defect_location_id?: string | null;
          photo_before_url?: string | null;
          photo_after_url?: string | null;
          action_taken?: string | null;
          wo_number?: string | null;
          technician_id?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      audit_logs: {
        Row: {
          id: string;
          user_id: string | null;
          action: string;
          record_id: string | null;
          table_name: string;
          old_value: Json | null;
          new_value: Json | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id?: string | null;
          action: string;
          record_id?: string | null;
          table_name: string;
          old_value?: Json | null;
          new_value?: Json | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string | null;
          action?: string;
          record_id?: string | null;
          table_name?: string;
          old_value?: Json | null;
          new_value?: Json | null;
          created_at?: string;
        };
      };
      wo_sequences: {
        Row: {
          id: string;
          prefix: string;
          current_number: number;
          updated_at: string;
        };
        Insert: {
          id?: string;
          prefix?: string;
          current_number?: number;
          updated_at?: string;
        };
        Update: {
          id?: string;
          prefix?: string;
          current_number?: number;
          updated_at?: string;
        };
      };
    };
    Enums: {};
  };
}
