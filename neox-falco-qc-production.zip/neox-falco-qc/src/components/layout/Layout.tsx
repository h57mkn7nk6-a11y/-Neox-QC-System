import { useAuth } from '@/hooks/useAuth';
import { useAppStore } from '@/hooks/useStore';
import { usePermission } from '@/hooks/usePermission';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, PlusCircle, Database, BarChart3, FileText, Settings, Shield, LogOut, Menu, X, Wrench, ClipboardList
} from 'lucide-react';
import { useState } from 'react';

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user, signOut } = useAuth();
  const { darkMode, toggleDarkMode } = useAppStore();
  const canViewAudit = usePermission('canViewAuditLog');
  const canManageWO = usePermission('canManageWorkOrders');
  const canManageMaint = usePermission('canManageMaintenance');
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  const navItems = [
    { path: '/', label: 'Dashboard', icon: LayoutDashboard, perm: 'canViewDashboard' },
    { path: '/entry', label: 'Quick Entry', icon: PlusCircle, perm: 'canAddRecords' },
    { path: '/records', label: 'Records', icon: Database, perm: 'canViewRecords' },
    { path: '/analytics', label: 'Analytics', icon: BarChart3, perm: 'canViewAnalytics' },
    { path: '/reports', label: 'Reports', icon: FileText, perm: 'canViewReports' },
  ];

  if (canManageWO) {
    navItems.push({ path: '/workorders', label: 'Work Orders', icon: ClipboardList, perm: 'canManageWorkOrders' });
  }
  if (canManageMaint) {
    navItems.push({ path: '/maintenance', label: 'Maintenance', icon: Wrench, perm: 'canManageMaintenance' });
  }
  if (usePermission('canManageSettings')) {
    navItems.push({ path: '/settings', label: 'Settings', icon: Settings, perm: 'canManageSettings' });
  }
  if (canViewAudit) {
    navItems.push({ path: '/audit', label: 'Audit Log', icon: Shield, perm: 'canViewAuditLog' });
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white dark:bg-neox-card border-b border-gray-200 dark:border-gray-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button className="lg:hidden p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <div>
              <h1 className="text-lg font-bold tracking-tight">NEOX FALCO</h1>
              <p className="text-xs text-gray-500 dark:text-gray-400 -mt-1">QC & PACKAGING</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden md:block text-right">
              <p className="text-sm font-medium">{user?.technician_name}</p>
              <p className="text-xs text-gray-500 font-bold uppercase">{user?.role}</p>
            </div>
            <button onClick={toggleDarkMode} className="p-2 rounded-lg bg-gray-100 dark:bg-gray-800">{darkMode ? '☀' : '🌙'}</button>
            <button onClick={signOut} className="p-2 rounded-lg bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400"><LogOut className="w-5 h-5" /></button>
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        <aside className={`fixed lg:static inset-y-0 left-0 z-30 w-64 bg-white dark:bg-neox-card border-r border-gray-200 dark:border-gray-800 transform transition-transform duration-200 lg:transform-none pt-16 lg:pt-0 ${menuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <nav className="p-4 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = location.pathname === item.path;
              return (
                <Link key={item.path} to={item.path} onClick={() => setMenuOpen(false)} className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium ${active ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800'}`}>
                  <Icon className="w-5 h-5" /> {item.label}
                </Link>
              );
            })}
          </nav>
        </aside>
        {menuOpen && <div className="fixed inset-0 bg-black/50 z-20 lg:hidden" onClick={() => setMenuOpen(false)} />}
        <main className="flex-1 p-4 lg:p-6 max-w-7xl mx-auto w-full">{children}</main>
      </div>
    </div>
  );
}
