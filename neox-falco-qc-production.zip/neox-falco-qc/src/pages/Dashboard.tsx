import { useEffect, useState } from 'react';
import { useDashboard } from '@/hooks/useDashboard';
import { useAuth } from '@/hooks/useAuth';
import { Link } from 'react-router-dom';
import { formatDate, formatTime } from '@/lib/utils';
import { CheckCircle, XCircle, Package, TrendingUp, PlusCircle, Database, BarChart3, FileText, Settings } from 'lucide-react';

export default function Dashboard() {
  const { stats, loading, fetchDashboard } = useDashboard();
  const { user } = useAuth();
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    fetchDashboard();
    const interval = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, [fetchDashboard]);

  const kpiCards = [
    { label: 'PASSED TODAY', value: stats?.passedToday ?? 0, icon: CheckCircle, color: 'text-green-500', bg: 'bg-green-50 dark:bg-green-900/20' },
    { label: 'DEFECTIVE TODAY', value: stats?.defectiveToday ?? 0, icon: XCircle, color: 'text-red-500', bg: 'bg-red-50 dark:bg-red-900/20' },
    { label: 'TOTAL PROCESSED', value: stats?.totalToday ?? 0, icon: Package, color: 'text-blue-500', bg: 'bg-blue-50 dark:bg-blue-900/20' },
    { label: 'DEFECT RATE', value: `${stats?.defectRate ?? 0}%`, icon: TrendingUp, color: 'text-amber-500', bg: 'bg-amber-50 dark:bg-amber-900/20' },
  ];

  const quickActions = [
    { label: 'QUICK ENTRY', path: '/entry', icon: PlusCircle, color: 'bg-blue-600 hover:bg-blue-700' },
    { label: 'RECORDS', path: '/records', icon: Database, color: 'bg-gray-700 hover:bg-gray-800' },
    { label: 'ANALYTICS', path: '/analytics', icon: BarChart3, color: 'bg-purple-600 hover:bg-purple-700' },
    { label: 'REPORTS', path: '/reports', icon: FileText, color: 'bg-emerald-600 hover:bg-emerald-700' },
    { label: 'SETTINGS', path: '/settings', icon: Settings, color: 'bg-slate-600 hover:bg-slate-700' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Main Dashboard</h2>
          <p className="text-gray-500 dark:text-gray-400">Technician: <span className="font-semibold text-gray-900 dark:text-white">{user?.technician_name}</span></p>
        </div>
        <div className="text-right">
          <p className="text-lg font-mono font-semibold">{formatDate(time.toISOString())}</p>
          <p className="text-2xl font-mono font-bold text-blue-600 dark:text-blue-400">{formatTime(time.toISOString())}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpiCards.map((card) => {
          const Icon = card.icon;
          return (
            <div key={card.label} className={`${card.bg} rounded-xl p-5 border border-gray-200 dark:border-gray-800`}>
              <div className="flex items-center justify-between mb-2">
                <Icon className={`w-6 h-6 ${card.color}`} />
                <span className="text-xs font-bold uppercase tracking-wider text-gray-500">{card.label}</span>
              </div>
              <p className="text-3xl font-bold">{loading ? '...' : card.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-neox-card rounded-xl p-5 border border-gray-200 dark:border-gray-800">
          <p className="text-sm text-gray-500 uppercase font-bold mb-1">Weekly Total</p>
          <p className="text-2xl font-bold">{stats?.weeklyTotal ?? 0}</p>
          <div className="flex gap-4 mt-2 text-sm">
            <span className="text-green-600">{stats?.weeklyPassed ?? 0} Passed</span>
            <span className="text-red-600">{stats?.weeklyDefective ?? 0} Defective</span>
          </div>
        </div>
        <div className="bg-white dark:bg-neox-card rounded-xl p-5 border border-gray-200 dark:border-gray-800">
          <p className="text-sm text-gray-500 uppercase font-bold mb-1">Weekly Defect Rate</p>
          <p className="text-2xl font-bold">{stats?.weeklyDefectRate ?? 0}%</p>
        </div>
        <div className="bg-white dark:bg-neox-card rounded-xl p-5 border border-gray-200 dark:border-gray-800">
          <p className="text-sm text-gray-500 uppercase font-bold mb-1">Repairs Completed</p>
          <p className="text-2xl font-bold">{stats?.repairCompletedToday ?? 0}</p>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-bold mb-3">Quick Navigation</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <Link key={action.path} to={action.path} className={`${action.color} text-white rounded-xl p-5 flex flex-col items-center gap-2 transition-transform hover:scale-105`}>
                <Icon className="w-8 h-8" />
                <span className="font-semibold text-sm text-center">{action.label}</span>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
