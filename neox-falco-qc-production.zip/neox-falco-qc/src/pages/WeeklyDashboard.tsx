import { useState, useEffect } from 'react';
import { useDashboard } from '@/hooks/useDashboard';
import { getToday, getWeekStart, getWeekEnd, getMonthStart, getMonthEnd } from '@/lib/utils';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';
import { Calendar, TrendingUp, CheckCircle, XCircle, Clock, Wrench } from 'lucide-react';

const COLORS = ['#3b82f6', '#22c55e', '#ef4444', '#f59e0b', '#8b5cf6', '#06b6d4', '#ec4899', '#84cc16'];

export default function WeeklyDashboard() {
  const { stats, defectLocations, technicianStats, dailyTrend, loading, fetchDashboard } = useDashboard();
  const [dateFrom, setDateFrom] = useState(getWeekStart());
  const [dateTo, setDateTo] = useState(getToday());
  const [period, setPeriod] = useState('week');

  useEffect(() => {
    fetchDashboard(dateFrom, dateTo);
  }, [dateFrom, dateTo, fetchDashboard]);

  const setPeriodRange = (p: string) => {
    setPeriod(p);
    switch (p) {
      case 'today':
        setDateFrom(getToday());
        setDateTo(getToday());
        break;
      case 'week':
        setDateFrom(getWeekStart());
        setDateTo(getWeekEnd());
        break;
      case 'month':
        setDateFrom(getMonthStart());
        setDateTo(getMonthEnd());
        break;
    }
  };

  const kpiCards = [
    { label: 'Total Processed', value: stats?.totalToday ?? 0, icon: TrendingUp, color: 'text-blue-500' },
    { label: 'Passed', value: stats?.passedToday ?? 0, icon: CheckCircle, color: 'text-green-500' },
    { label: 'Defective', value: stats?.defectiveToday ?? 0, icon: XCircle, color: 'text-red-500' },
    { label: 'Repair Pending', value: stats?.repairPendingToday ?? 0, icon: Clock, color: 'text-amber-500' },
    { label: 'Repair Completed', value: stats?.repairCompletedToday ?? 0, icon: Wrench, color: 'text-cyan-500' },
    { label: 'Defect Rate', value: `${stats?.defectRate ?? 0}%`, icon: XCircle, color: 'text-red-500' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold">Analytics Dashboard</h2>
        <div className="flex flex-wrap gap-2">
          {[
            { key: 'today', label: 'Today' },
            { key: 'week', label: 'This Week' },
            { key: 'month', label: 'This Month' },
          ].map((p) => (
            <button
              key={p.key}
              onClick={() => setPeriodRange(p.key)}
              className={`px-4 py-2 rounded-lg text-sm font-medium ${
                period === p.key
                  ? 'bg-blue-600 text-white'
                  : 'bg-white dark:bg-neox-card border border-gray-300 dark:border-gray-700'
              }`}
            >
              {p.label}
            </button>
          ))}
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-gray-400" />
            <input type="date" value={dateFrom} onChange={(e) => { setDateFrom(e.target.value); setPeriod('custom'); }} className="px-2 py-1.5 text-sm" />
            <span className="text-gray-400">-</span>
            <input type="date" value={dateTo} onChange={(e) => { setDateTo(e.target.value); setPeriod('custom'); }} className="px-2 py-1.5 text-sm" />
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {kpiCards.map((kpi) => {
          const Icon = kpi.icon;
          return (
            <div key={kpi.label} className="bg-white dark:bg-neox-card rounded-xl p-4 border border-gray-200 dark:border-gray-800">
              <Icon className={`w-5 h-5 ${kpi.color} mb-2`} />
              <p className="text-2xl font-bold">{loading ? '...' : kpi.value}</p>
              <p className="text-xs text-gray-500 uppercase font-bold mt-1">{kpi.label}</p>
            </div>
          );
        })}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Production Trend */}
        <div className="bg-white dark:bg-neox-card rounded-xl p-5 border border-gray-200 dark:border-gray-800">
          <h3 className="text-lg font-bold mb-4">Production Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={dailyTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.2} />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Legend />
              <Bar dataKey="passed" fill="#22c55e" name="Passed" radius={[4, 4, 0, 0]} />
              <Bar dataKey="defective" fill="#ef4444" name="Defective" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Defect Locations */}
        <div className="bg-white dark:bg-neox-card rounded-xl p-5 border border-gray-200 dark:border-gray-800">
          <h3 className="text-lg font-bold mb-4">Defect Locations</h3>
          {defectLocations.length === 0 ? (
            <div className="h-[300px] flex items-center justify-center text-gray-500">No defect data</div>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={defectLocations}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  dataKey="count"
                  nameKey="location_name"
                  label={({ location_name, count }) => `${location_name}: ${count}`}
                >
                  {defectLocations.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Technician Performance */}
      <div className="bg-white dark:bg-neox-card rounded-xl p-5 border border-gray-200 dark:border-gray-800">
        <h3 className="text-lg font-bold mb-4">Technician Performance</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={technicianStats} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.2} />
            <XAxis type="number" tick={{ fontSize: 12 }} />
            <YAxis dataKey="technician_name" type="category" tick={{ fontSize: 12 }} width={120} />
            <Tooltip />
            <Legend />
            <Bar dataKey="passed" fill="#22c55e" name="Passed" radius={[0, 4, 4, 0]} />
            <Bar dataKey="defective" fill="#ef4444" name="Defective" radius={[0, 4, 4, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
