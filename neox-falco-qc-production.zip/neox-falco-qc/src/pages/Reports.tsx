import { useState } from 'react';
import { useDashboard } from '@/hooks/useDashboard';
import { getToday, getWeekStart, getWeekEnd, getMonthStart, getMonthEnd } from '@/lib/utils';
import { Download, FileText, FileSpreadsheet, Table } from 'lucide-react';

export default function Reports() {
  const { stats, defectLocations, technicianStats, dailyTrend, fetchDashboard } = useDashboard();
  const [dateFrom, setDateFrom] = useState(getWeekStart());
  const [dateTo, setDateTo] = useState(getToday());
  const [generating, setGenerating] = useState(false);

  const generateReport = async () => {
    setGenerating(true);
    await fetchDashboard(dateFrom, dateTo);
    setGenerating(false);
  };

  const exportCSV = () => {
    const headers = ['Date', 'Total', 'Passed', 'Defective'];
    const rows = dailyTrend.map(d => [d.date, d.total, d.passed, d.defective].join(','));
    const csv = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `neox-report-${dateFrom}-to-${dateTo}.csv`;
    a.click();
  };

  const exportExcel = () => {
    // Using simple CSV as Excel-compatible format for now
    exportCSV();
  };

  const exportPDF = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold">Reports</h2>
        <div className="flex gap-2">
          <button onClick={exportPDF} className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
            <FileText className="w-4 h-4" /> PDF
          </button>
          <button onClick={exportExcel} className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
            <FileSpreadsheet className="w-4 h-4" /> Excel
          </button>
          <button onClick={exportCSV} className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700">
            <Table className="w-4 h-4" /> CSV
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-neox-card rounded-xl border border-gray-200 dark:border-gray-800 p-4 flex flex-wrap gap-3 items-end">
        <div>
          <label className="text-xs font-bold text-gray-500 uppercase">From</label>
          <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="block mt-1 px-3 py-2" />
        </div>
        <div>
          <label className="text-xs font-bold text-gray-500 uppercase">To</label>
          <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="block mt-1 px-3 py-2" />
        </div>
        <button
          onClick={generateReport}
          disabled={generating}
          className="px-6 py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50"
        >
          {generating ? 'Generating...' : 'Generate Report'}
        </button>
      </div>

      {/* Report Preview */}
      <div id="report-preview" className="bg-white dark:bg-neox-card rounded-xl border border-gray-200 dark:border-gray-800 p-8 space-y-6">
        <div className="text-center border-b-2 border-gray-200 dark:border-gray-700 pb-4">
          <h1 className="text-3xl font-bold">NEOX FALCO</h1>
          <p className="text-lg text-gray-500">Quality Control & Packaging Department</p>
          <p className="text-sm text-gray-400 mt-2">Report Period: {dateFrom} to {dateTo}</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg text-center">
            <p className="text-3xl font-bold">{stats?.totalToday ?? 0}</p>
            <p className="text-xs uppercase font-bold text-gray-500">Total Processed</p>
          </div>
          <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg text-center">
            <p className="text-3xl font-bold text-green-600">{stats?.passedToday ?? 0}</p>
            <p className="text-xs uppercase font-bold text-green-600">Passed</p>
          </div>
          <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg text-center">
            <p className="text-3xl font-bold text-red-600">{stats?.defectiveToday ?? 0}</p>
            <p className="text-xs uppercase font-bold text-red-600">Defective</p>
          </div>
          <div className="p-4 bg-amber-50 dark:bg-amber-900/20 rounded-lg text-center">
            <p className="text-3xl font-bold text-amber-600">{stats?.defectRate ?? 0}%</p>
            <p className="text-xs uppercase font-bold text-amber-600">Defect Rate</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-bold mb-3">Top Defect Locations</h3>
            <table className="w-full text-sm">
              <thead className="bg-gray-100 dark:bg-gray-800">
                <tr><th className="px-3 py-2 text-left">Location</th><th className="px-3 py-2 text-right">Count</th></tr>
              </thead>
              <tbody>
                {defectLocations.slice(0, 5).map((d) => (
                  <tr key={d.location_name} className="border-b border-gray-100 dark:border-gray-800">
                    <td className="px-3 py-2">{d.location_name}</td>
                    <td className="px-3 py-2 text-right font-bold">{d.count}</td>
                  </tr>
                ))}
                {defectLocations.length === 0 && (
                  <tr><td colSpan={2} className="px-3 py-4 text-center text-gray-500">No data</td></tr>
                )}
              </tbody>
            </table>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-3">Technician Statistics</h3>
            <table className="w-full text-sm">
              <thead className="bg-gray-100 dark:bg-gray-800">
                <tr><th className="px-3 py-2 text-left">Technician</th><th className="px-3 py-2 text-right">Total</th><th className="px-3 py-2 text-right">Passed</th><th className="px-3 py-2 text-right">Defective</th></tr>
              </thead>
              <tbody>
                {technicianStats.map((t) => (
                  <tr key={t.technician_name} className="border-b border-gray-100 dark:border-gray-800">
                    <td className="px-3 py-2">{t.technician_name}</td>
                    <td className="px-3 py-2 text-right font-bold">{t.count}</td>
                    <td className="px-3 py-2 text-right text-green-600">{t.passed}</td>
                    <td className="px-3 py-2 text-right text-red-600">{t.defective}</td>
                  </tr>
                ))}
                {technicianStats.length === 0 && (
                  <tr><td colSpan={4} className="px-3 py-4 text-center text-gray-500">No data</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="text-center text-xs text-gray-400 pt-4 border-t border-gray-200 dark:border-gray-700">
          Generated by NEOX FALCO QC System | {new Date().toLocaleString()}
        </div>
      </div>
    </div>
  );
}
