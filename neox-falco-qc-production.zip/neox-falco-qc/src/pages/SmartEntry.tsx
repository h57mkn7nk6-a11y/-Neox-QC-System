import { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useRecords } from '@/hooks/useRecords';
import { useReferenceData } from '@/hooks/useReferenceData';
import { useAppStore } from '@/hooks/useStore';
import { compressImage } from '@/lib/utils';
import { supabase } from '@/lib/supabase';
import { Camera, ScanLine, Save, AlertTriangle } from 'lucide-react';

type EntryMode = 'PASSED' | 'DEFECTIVE';

export default function SmartEntry() {
  const { user } = useAuth();
  const { createRecord, checkDuplicateSN, generateWONumber } = useRecords();
  const { models, defectLocations, fetchModels, fetchDefectLocations } = useReferenceData();
  const { addNotification, isOnline } = useAppStore();

  const [mode, setMode] = useState<EntryMode>('PASSED');
  const [modelId, setModelId] = useState('');
  const [deviceSN, setDeviceSN] = useState('');
  const [reason, setReason] = useState('');
  const [defectLocationId, setDefectLocationId] = useState('');
  const [actionTaken, setActionTaken] = useState('');
  const [woNumber, setWoNumber] = useState('');
  const [photoBefore, setPhotoBefore] = useState<File | null>(null);
  const [photoAfter, setPhotoAfter] = useState<File | null>(null);
  const [photoBeforePreview, setPhotoBeforePreview] = useState('');
  const [photoAfterPreview, setPhotoAfterPreview] = useState('');
  const [duplicateWarning, setDuplicateWarning] = useState<any>(null);
  const [saving, setSaving] = useState(false);

  const snInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { fetchModels(); fetchDefectLocations(); }, []);
  useEffect(() => { if (mode === 'DEFECTIVE' && !woNumber) generateWONumber().then(setWoNumber); }, [mode]);

  const handleSNChange = async (val: string) => {
    setDeviceSN(val);
    setDuplicateWarning(null);
    if (val.length > 3) {
      const existing = await checkDuplicateSN(val);
      if (existing) setDuplicateWarning(existing);
    }
  };

  const handlePhoto = async (e: React.ChangeEvent<HTMLInputElement>, type: 'before' | 'after') => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      // Compress: 75% quality, max width 1200px for iPad optimization
      const compressed = await compressImage(file, 1200, 0.75);
      const blobUrl = URL.createObjectURL(compressed);
      const newFile = new File([compressed], file.name, { type: 'image/jpeg' });
      if (type === 'before') { setPhotoBefore(newFile); setPhotoBeforePreview(blobUrl); }
      else { setPhotoAfter(newFile); setPhotoAfterPreview(blobUrl); }
    } catch { addNotification('Image processing failed', 'error'); }
  };

  const uploadPhoto = async (file: File, path: string): Promise<string | null> => {
    const fileName = `${path}/${crypto.randomUUID()}.jpg`;
    // Upload to new bucket: qc-defect-images
    const { error } = await supabase.storage.from('qc-defect-images').upload(fileName, file);
    if (error) { addNotification('Upload failed: ' + error.message, 'error'); return null; }
    const { data } = supabase.storage.from('qc-defect-images').getPublicUrl(fileName);
    return data.publicUrl;
  };

  const resetForm = () => {
    setDeviceSN(''); setReason(''); setDefectLocationId(''); setActionTaken('');
    setPhotoBefore(null); setPhotoAfter(null); setPhotoBeforePreview(''); setPhotoAfterPreview('');
    setDuplicateWarning(null);
    if (mode === 'DEFECTIVE') generateWONumber().then(setWoNumber);
    setTimeout(() => snInputRef.current?.focus(), 100);
  };

  const handleSave = async () => {
    if (!modelId || !deviceSN) { addNotification('Model and Device SN required', 'warning'); return; }
    if (mode === 'DEFECTIVE') {
      if (!reason || !defectLocationId || !actionTaken || !photoBefore) {
        addNotification('Fill all defect fields and upload BEFORE photo', 'warning'); return;
      }
      if (actionTaken === 'Repaired' && !photoAfter) {
        addNotification('Photo AFTER required for completed repairs', 'warning'); return;
      }
    }
    setSaving(true);
    try {
      let beforeUrl = null, afterUrl = null;
      if (photoBefore && isOnline) beforeUrl = await uploadPhoto(photoBefore, 'before');
      if (photoAfter && isOnline) afterUrl = await uploadPhoto(photoAfter, 'after');
      const record = await createRecord({
        model_id: modelId,
        device_sn: deviceSN.trim().toUpperCase(),
        status: mode === 'PASSED' ? 'PASSED' : 'DEFECTIVE',
        reason_for_replacement: mode === 'DEFECTIVE' ? reason : null,
        defect_location_id: mode === 'DEFECTIVE' ? defectLocationId : null,
        photo_before_url: beforeUrl,
        photo_after_url: afterUrl,
        action_taken: mode === 'DEFECTIVE' ? actionTaken : null,
        wo_number: mode === 'DEFECTIVE' ? woNumber : null,
        technician_id: user?.id,
      });
      if (record) { addNotification(`${mode} record saved`, 'success'); resetForm(); }
    } catch (err: any) { addNotification(err.message || 'Save failed', 'error'); }
    finally { setSaving(false); }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Smart Entry</h2>
        <div className="flex bg-gray-200 dark:bg-gray-800 rounded-lg p-1">
          <button onClick={() => setMode('PASSED')} className={`px-6 py-2 rounded-md font-semibold text-sm ${mode === 'PASSED' ? 'bg-green-500 text-white' : 'text-gray-600 dark:text-gray-400'}`}>PASSED</button>
          <button onClick={() => setMode('DEFECTIVE')} className={`px-6 py-2 rounded-md font-semibold text-sm ${mode === 'DEFECTIVE' ? 'bg-red-500 text-white' : 'text-gray-600 dark:text-gray-400'}`}>DEFECTIVE</button>
        </div>
      </div>

      <div className="bg-white dark:bg-neox-card rounded-xl p-5 border border-gray-200 dark:border-gray-800 space-y-4">
        <div>
          <label className="block text-sm font-bold mb-2">Model NO *</label>
          <select value={modelId} onChange={(e) => setModelId(e.target.value)} className="w-full px-4 py-3 text-lg">
            <option value="">Select Model...</option>
            {models.map((m) => <option key={m.id} value={m.id}>{m.model_no} {m.model_name ? `(${m.model_name})` : ''}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-bold mb-2">Device SN *</label>
          <div className="flex gap-2">
            <input ref={snInputRef} type="text" value={deviceSN} onChange={(e) => handleSNChange(e.target.value)} className="flex-1 px-4 py-3 text-lg font-mono uppercase" placeholder="Scan or type serial number..." autoFocus />
            <button type="button" onClick={() => addNotification('Camera scanning not available', 'info')} className="px-4 py-3 bg-gray-100 dark:bg-gray-800 rounded-lg"><ScanLine className="w-6 h-6" /></button>
          </div>
          {duplicateWarning && (
            <div className="mt-2 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 rounded-lg flex items-start gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-bold text-amber-800 dark:text-amber-400">Duplicate SN Warning</p>
                <p>Exists: {duplicateWarning.status} on {duplicateWarning.date} | WO: {duplicateWarning.wo_number || 'N/A'}</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {mode === 'DEFECTIVE' && (
        <div className="bg-white dark:bg-neox-card rounded-xl p-5 border border-gray-200 dark:border-gray-800 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-bold mb-2">Reason For Replacement *</label>
              <textarea value={reason} onChange={(e) => setReason(e.target.value)} className="w-full px-4 py-3" rows={3} placeholder="Describe defect reason..." />
            </div>
            <div>
              <label className="block text-sm font-bold mb-2">Defect Location *</label>
              <select value={defectLocationId} onChange={(e) => setDefectLocationId(e.target.value)} className="w-full px-4 py-3">
                <option value="">Select Location...</option>
                {defectLocations.map((d) => <option key={d.id} value={d.id}>{d.location_name}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-bold mb-2">Action Taken *</label>
            <select value={actionTaken} onChange={(e) => setActionTaken(e.target.value)} className="w-full px-4 py-3">
              <option value="">Select Action...</option>
              {['Repaired','Replaced','Adjusted','Reassembled','Sent to Assembly','Sent to Maintenance','Replaced Part','Other'].map(a => <option key={a} value={a}>{a}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-bold mb-2">WO Number</label>
            <input type="text" value={woNumber} onChange={(e) => setWoNumber(e.target.value)} className="w-full px-4 py-3 font-mono" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-bold mb-2">Photo BEFORE *</label>
              <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-4 text-center">
                {photoBeforePreview ? <img src={photoBeforePreview} alt="Before" className="mx-auto max-h-40 rounded-lg" /> :
                  <label className="cursor-pointer block py-6"><Camera className="w-8 h-8 mx-auto text-gray-400 mb-2" /><span className="text-sm text-gray-500">Tap to capture</span><input type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => handlePhoto(e, 'before')} /></label>}
              </div>
            </div>
            <div>
              <label className="block text-sm font-bold mb-2">Photo AFTER {actionTaken === 'Repaired' ? '*' : ''}</label>
              <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-4 text-center">
                {photoAfterPreview ? <img src={photoAfterPreview} alt="After" className="mx-auto max-h-40 rounded-lg" /> :
                  <label className="cursor-pointer block py-6"><Camera className="w-8 h-8 mx-auto text-gray-400 mb-2" /><span className="text-sm text-gray-500">Tap to capture</span><input type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => handlePhoto(e, 'after')} /></label>}
              </div>
            </div>
          </div>
        </div>
      )}

      <button onClick={handleSave} disabled={saving} className={`w-full py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 text-white disabled:opacity-50 ${mode === 'PASSED' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}`}>
        <Save className="w-6 h-6" /> {saving ? 'SAVING...' : `SAVE ${mode}`}
      </button>
    </div>
  );
}
