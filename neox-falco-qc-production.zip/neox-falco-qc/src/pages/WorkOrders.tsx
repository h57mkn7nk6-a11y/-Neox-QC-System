import { usePermission } from '@/hooks/usePermission';
import { ClipboardList } from 'lucide-react';

export default function WorkOrders() {
  const canManage = usePermission('canManageWorkOrders');

  if (!canManage) {
    return (
      <div className="text-center py-20">
        <p className="text-gray-500">You do not have permission to manage work orders.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <ClipboardList className="w-6 h-6 text-blue-600" />
        <h2 className="text-2xl font-bold">Work Orders</h2>
      </div>
      <div className="bg-white dark:bg-neox-card rounded-xl border border-gray-200 dark:border-gray-800 p-8 text-center">
        <p className="text-gray-500">Work Orders module is under development.</p>
        <p className="text-sm text-gray-400 mt-2">Contact Admin for updates.</p>
      </div>
    </div>
  );
}
