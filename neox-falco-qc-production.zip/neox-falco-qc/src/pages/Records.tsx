import { useState, useEffect, useCallback } from 'react';
import { useRecords, RecordFilters } from '@/hooks/useRecords';
import { useReferenceData } from '@/hooks/useReferenceData';
import { usePermission } from '@/hooks/usePermission';
import { Link } from 'react-router-dom';
import { formatDate, formatTime } from '@/lib/utils';
import { STATUS_COLORS } from '@/lib/constants';
import {
  Search, Filter, Eye, Pencil, Trash2, ChevronLeft, ChevronRight
} from 'lucide-react';

export default function Records() {
  const { records, loading, totalCount, fetchRecords, deleteRecord } = useRecords();
  const { models, defectLocations, technicians } = useReferenceData();
  const canDelete = usePermission('canDeleteRecords');
  const canEdit = usePermission('canEditRecords');

  const [filters, setFilters] = useState<RecordFilters>({});
  const [page, setPage] = useState(1);
  const [showFilters, setShowFilters] = useState(false);
  const pageSize = 50;

  const applyFilters = useCallback(() => {
    fetchRecords(filters, page, pageSize);
  }, [filters, page, fetchRecords]);

  useEffect(() => {
    applyFilters();
  }, [applyFilters]);

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this record?')) return;
    const success = await deleteRecord(id);
    if (success) applyFilters();
  };

  const totalPages = Math.ceil(totalCount / pageSize);

  const statusBadge = (status: string) => {
    const config = STATUS_COLORS[status as keyof typeof STATUS_COLORS];
    if (!config) return null;
    return (
      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold ${config.bg.replace('bg-', 'bg-opacity-20 text-')}`}>
        <span className={`w-2 h-2 rounded-full ${config.bg}`} />
        {config.label}
      </span>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <h2 className="text-2xl font-bold">Production Records</h2>
        <div className="flex gap-2">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg border ${showFilters ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-300' : 'border-gray-300 dark:border-gray-700'}`}
          >
            <Filter className="w-4 h-4" /> Filters
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-neox-card rounded-xl border border-gray-200 dark:border-gray-800 p-4 space-y-3">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search by SN, WO Number..."
              className="w-full pl-10 pr-4 py-2.5"
              value={filters.search || ''}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
              onKeyDown={(e) => e.key === 'Enter' && applyFilters()}
            />
          </div>
          <button
            onClick={applyFilters}
            className="px-6 py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700"
          >
            Search
          </button>
        </div>

        {showFilters && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-3 border-t border-gray-200 dark:border-gray-700">
            <select
              value={filters.status || 'ALL'}
              onChange={(e) => setFilters({ ...filters, status: e.target.value as any })}
              className="px-3 py-2"
            >
              <option value="ALL">All Status</option>
              <option value="PASSED">Passed</option>
              <option value="DEFECTIVE">Defective</option>
              <option value="REPAIR_PENDING">Repair Pending</option>
              <option value="REPAIR_COMPLETED">Repair Completed</option>
            </select>
            <select
              value={filters.modelId || ''}
              onChange={(e) => setFilters({ ...filters, modelId: e.target.value || undefined })}
              className="px-3 py-2"
            >
              <option value="">All Models</option>
              {models.map((m) => (
                <option key={m.id} value={m.id}>{m.model_no}</option>
              ))}
            </select>
            <select
              value={filters.defectLocationId || ''}
              onChange={(e) => setFilters({ ...filters, defectLocationId: e.target.value || undefined })}
              className="px-3 py-2"
            >
              <option value="">All Locations</option>
              {defectLocations.map((d) => (
                <option key={d.id} value={d.id}>{d.location_name}</option>
              ))}
            </select>
            <select
              value={filters.technicianId || ''}
              onChange={(e) => setFilters({ ...filters, technicianId: e.target.value || undefined })}
              className="px-3 py-2"
            >
              <option value="">All Technicians</option>
              {technicians.map((t) => (
                <option key={t.id} value={t.id}>{t.technician_name}</option>
              ))}
            </select>
            <input type="date" value={filters.dateFrom || ''} onChange={(e) => setFilters({ ...filters, dateFrom: e.target.value || undefined })} className="px-3 py-2" />
            <input type="date" value={filters.dateTo || ''} onChange={(e) => setFilters({ ...filters, dateTo: e.target.value || undefined })} className="px-3 py-2" />
          </div>
        )}
      </div>

      <div className="bg-white dark:bg-neox-card rounded-xl border border-gray-200 dark:border-gray-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 dark:bg-gray-800/50 text-gray-600 dark:text-gray-400 uppercase text-xs font-bold">
              <tr>
                <th className="px-4 py-3 text-left">Date/Time</th>
                <th className="px-4 py-3 text-left">Model</th>
                <th className="px-4 py-3 text-left">Device SN</th>
                <th className="px-4 py-3 text-left">Status</th>
                <th className="px-4 py-3 text-left hidden md:table-cell">WO</th>
                <th className="px-4 py-3 text-left hidden lg:table-cell">Location</th>
                <th className="px-4 py-3 text-left hidden lg:table-cell">Tech</th>
                <th className="px-4 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {loading ? (
                <tr><td colSpan={8} className="text-center py-12 text-gray-500">Loading...</td></tr>
              ) : records.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-12 text-gray-500">No records found</td></tr>
              ) : (
                records.map((record) => (
                  <tr key={record.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/30">
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="font-medium">{formatDate(record.date)}</div>
                      <div className="text-xs text-gray-500">{record.time}</div>
                    </td>
                    <td className="px-4 py-3 font-mono">{record.model?.model_no || '-'}</td>
                    <td className="px-4 py-3 font-mono text-xs">{record.device_sn}</td>
                    <td className="px-4 py-3">{statusBadge(record.status)}</td>
                    <td className="px-4 py-3 hidden md:table-cell font-mono text-xs">{record.wo_number || '-'}</td>
                    <td className="px-4 py-3 hidden lg:table-cell text-xs">{record.defect_location?.location_name || '-'}</td>
                    <td className="px-4 py-3 hidden lg:table-cell text-xs">{record.technician?.technician_name || '-'}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <Link to={`/records/${record.id}`} className="p-1.5 rounded hover:bg-gray-100 dark:hover:bg-gray-800 text-blue-600">
                          <Eye className="w-4 h-4" />
                        </Link>
                        {canEdit && (
                          <Link to={`/records/${record.id}?edit=1`} className="p-1.5 rounded hover:bg-gray-100 dark:hover:bg-gray-800 text-amber-600">
                            <Pencil className="w-4 h-4" />
                          </Link>
                        )}
                        {canDelete && (
                          <button onClick={() => handleDelete(record.id)} className="p-1.5 rounded hover:bg-gray-100 dark:hover:bg-gray-800 text-red-600">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between px-4 py-3 border-t border-gray-200 dark:border-gray-800">
          <p className="text-sm text-gray-500">Showing {records.length} of {totalCount} records</p>
          <div className="flex items-center gap-2">
            <button onClick={() => setPage(Math.max(1, page - 1))} disabled={page === 1} className="p-2 rounded-lg border border-gray-300 dark:border-gray-700 disabled:opacity-30">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-sm font-medium px-2">{page} / {totalPages || 1}</span>
            <button onClick={() => setPage(Math.min(totalPages, page + 1))} disabled={page >= totalPages} className="p-2 rounded-lg border border-gray-300 dark:border-gray-700 disabled:opacity-30">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
