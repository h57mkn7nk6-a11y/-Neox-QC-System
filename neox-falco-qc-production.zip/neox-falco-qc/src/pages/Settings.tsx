import { useState } from 'react';
import { useReferenceData } from '@/hooks/useReferenceData';
import { usePermission } from '@/hooks/usePermission';
import { useAppStore } from '@/hooks/useStore';
import { Plus, Trash2, ToggleLeft, ToggleRight } from 'lucide-react';

export default function Settings() {
  const { models, defectLocations, createModel, createDefectLocation, fetchModels, fetchDefectLocations } = useReferenceData();
  const canManageModels = usePermission('canManageModels');
  const canManageSettings = usePermission('canManageSettings');
  const { addNotification } = useAppStore();

  const [newModelNo, setNewModelNo] = useState('');
  const [newModelName, setNewModelName] = useState('');
  const [newLocation, setNewLocation] = useState('');
  const [activeTab, setActiveTab] = useState<'models' | 'locations'>('models');

  const handleAddModel = async () => {
    if (!newModelNo.trim()) return;
    await createModel({ model_no: newModelNo.trim(), model_name: newModelName.trim() || null });
    setNewModelNo('');
    setNewModelName('');
    addNotification('Model added successfully', 'success');
  };

  const handleAddLocation = async () => {
    if (!newLocation.trim()) return;
    await createDefectLocation({ location_name: newLocation.trim() });
    setNewLocation('');
    addNotification('Defect location added successfully', 'success');
  };

  if (!canManageModels && !canManageSettings) {
    return (
      <div className="text-center py-20">
        <p className="text-gray-500">You do not have permission to access settings.</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold">Settings</h2>

      <div className="flex gap-2 border-b border-gray-200 dark:border-gray-800">
        <button
          onClick={() => setActiveTab('models')}
          className={`px-4 py-3 text-sm font-bold border-b-2 ${activeTab === 'models' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500'}`}
        >
          Model Numbers
        </button>
        <button
          onClick={() => setActiveTab('locations')}
          className={`px-4 py-3 text-sm font-bold border-b-2 ${activeTab === 'locations' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500'}`}
        >
          Defect Locations
        </button>
      </div>

      {activeTab === 'models' && (
        <div className="bg-white dark:bg-neox-card rounded-xl border border-gray-200 dark:border-gray-800 p-5 space-y-4">
          <h3 className="text-lg font-bold">Manage Models</h3>
          <div className="flex gap-2">
            <input
              value={newModelNo}
              onChange={(e) => setNewModelNo(e.target.value)}
              placeholder="Model NO (e.g. 7326)"
              className="flex-1 px-4 py-2"
            />
            <input
              value={newModelName}
              onChange={(e) => setNewModelName(e.target.value)}
              placeholder="Model Name (e.g. NX4148)"
              className="flex-1 px-4 py-2"
            />
            <button onClick={handleAddModel} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-1">
              <Plus className="w-4 h-4" /> Add
            </button>
          </div>
          <div className="border border-gray-200 dark:border-gray-800 rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-800/50 text-xs uppercase font-bold text-gray-500">
                <tr><th className="px-4 py-2 text-left">Model NO</th><th className="px-4 py-2 text-left">Name</th><th className="px-4 py-2 text-left">Status</th></tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {models.map((m) => (
                  <tr key={m.id}>
                    <td className="px-4 py-2 font-mono font-bold">{m.model_no}</td>
                    <td className="px-4 py-2">{m.model_name || '-'}</td>
                    <td className="px-4 py-2">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${m.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                        {m.active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'locations' && (
        <div className="bg-white dark:bg-neox-card rounded-xl border border-gray-200 dark:border-gray-800 p-5 space-y-4">
          <h3 className="text-lg font-bold">Manage Defect Locations</h3>
          <div className="flex gap-2">
            <input
              value={newLocation}
              onChange={(e) => setNewLocation(e.target.value)}
              placeholder="Location name (e.g. Rear Cover)"
              className="flex-1 px-4 py-2"
            />
            <button onClick={handleAddLocation} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-1">
              <Plus className="w-4 h-4" /> Add
            </button>
          </div>
          <div className="border border-gray-200 dark:border-gray-800 rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 dark:bg-gray-800/50 text-xs uppercase font-bold text-gray-500">
                <tr><th className="px-4 py-2 text-left">Location Name</th><th className="px-4 py-2 text-left">Status</th></tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {defectLocations.map((d) => (
                  <tr key={d.id}>
                    <td className="px-4 py-2 font-medium">{d.location_name}</td>
                    <td className="px-4 py-2">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${d.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                        {d.active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
