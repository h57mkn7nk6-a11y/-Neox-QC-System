import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { usePermission } from '@/hooks/usePermission';
import { formatDateTime } from '@/lib/utils';
import { Shield, AlertTriangle } from 'lucide-react';

export default function AuditLog() {
  const canViewAudit = usePermission('canViewAuditLog');
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!canViewAudit) return;
    fetchLogs();
  }, [canViewAudit]);

  const fetchLogs = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('audit_logs')
      .select('*, technician:technicians(technician_name)')
      .order('created_at', { ascending: false })
      .limit(200);
    if (!error) setLogs(data || []);
    setLoading(false);
  };

  if (!canViewAudit) {
    return (
      <div className="text-center py-20">
        <AlertTriangle className="w-12 h-12 mx-auto text-amber-500 mb-3" />
        <p className="text-gray-500">Admin access required to view audit logs.</p>
      </div>
    );
  }

  const actionColors: Record<string, string> = {
    CREATE: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
    UPDATE: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
    DELETE: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Shield className="w-6 h-6 text-blue-600" />
        <h2 className="text-2xl font-bold">Audit Log</h2>
      </div>

      <div className="bg-white dark:bg-neox-card rounded-xl border border-gray-200 dark:border-gray-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 dark:bg-gray-800/50 text-gray-600 dark:text-gray-400 uppercase text-xs font-bold">
              <tr>
                <th className="px-4 py-3 text-left">Time</th>
                <th className="px-4 py-3 text-left">User</th>
                <th className="px-4 py-3 text-left">Action</th>
                <th className="px-4 py-3 text-left">Table</th>
                <th className="px-4 py-3 text-left">Record ID</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {loading ? (
                <tr><td colSpan={5} className="text-center py-12 text-gray-500">Loading...</td></tr>
              ) : logs.length === 0 ? (
                <tr><td colSpan={5} className="text-center py-12 text-gray-500">No audit logs found</td></tr>
              ) : (
                logs.map((log) => (
                  <tr key={log.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/30">
                    <td className="px-4 py-3 whitespace-nowrap text-xs">{formatDateTime(log.created_at)}</td>
                    <td className="px-4 py-3">{log.technician?.technician_name || 'System'}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${actionColors[log.action] || 'bg-gray-100'}`}>
                        {log.action}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs font-mono">{log.table_name}</td>
                    <td className="px-4 py-3 text-xs font-mono text-gray-500">{log.record_id?.slice(0, 8)}...</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
