import { useState, useEffect } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import { useRecords } from '@/hooks/useRecords';
import { useReferenceData } from '@/hooks/useReferenceData';
import { usePermission } from '@/hooks/usePermission';
import { useAppStore } from '@/hooks/useStore';
import { formatDate, formatDateTime } from '@/lib/utils';
import { STATUS_COLORS } from '@/lib/constants';
import { ArrowLeft, ImageOff, Save, X } from 'lucide-react';

export default function RecordDetail() {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { getRecordById, updateRecord } = useRecords();
  const { models, defectLocations } = useReferenceData();
  const canEdit = usePermission('canEditRecords');
  const { addNotification } = useAppStore();

  const [record, setRecord] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [editMode, setEditMode] = useState(searchParams.get('edit') === '1');
  const [editData, setEditData] = useState<any>({});
  const [photoModal, setPhotoModal] = useState<string | null>(null);

  useEffect(() => {
    loadRecord();
  }, [id]);

  const loadRecord = async () => {
    if (!id) return;
    setLoading(true);
    const data = await getRecordById(id);
    setRecord(data);
    setEditData(data || {});
    setLoading(false);
  };

  const handleSave = async () => {
    if (!id) return;
    const success = await updateRecord(id, {
      model_id: editData.model_id,
      device_sn: editData.device_sn,
      status: editData.status,
      reason_for_replacement: editData.reason_for_replacement,
      defect_location_id: editData.defect_location_id,
      action_taken: editData.action_taken,
      wo_number: editData.wo_number,
    });
    if (success) {
      setEditMode(false);
      loadRecord();
    }
  };

  const statusConfig = record ? STATUS_COLORS[record.status as keyof typeof STATUS_COLORS] : null;

  if (loading) return <div className="text-center py-20">Loading...</div>;
  if (!record) return <div className="text-center py-20 text-red-500">Record not found</div>;

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <button onClick={() => navigate('/records')} className="flex items-center gap-2 text-gray-500 hover:text-gray-900 dark:hover:text-white">
          <ArrowLeft className="w-5 h-5" /> Back to Records
        </button>
        {canEdit && !editMode && (
          <button onClick={() => setEditMode(true)} className="px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700">
            Edit Record
          </button>
        )}
        {editMode && (
          <div className="flex gap-2">
            <button onClick={() => setEditMode(false)} className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
              <X className="w-4 h-4 inline mr-1" /> Cancel
            </button>
            <button onClick={handleSave} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              <Save className="w-4 h-4 inline mr-1" /> Save
            </button>
          </div>
        )}
      </div>

      {/* Device Info */}
      <div className="bg-white dark:bg-neox-card rounded-xl border border-gray-200 dark:border-gray-800 p-6 space-y-4">
        <h3 className="text-lg font-bold border-b border-gray-200 dark:border-gray-800 pb-2">Device Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-bold text-gray-500 uppercase">Model</label>
            {editMode ? (
              <select value={editData.model_id || ''} onChange={(e) => setEditData({ ...editData, model_id: e.target.value })} className="w-full mt-1 px-3 py-2">
                {models.map((m) => <option key={m.id} value={m.id}>{m.model_no}</option>)}
              </select>
            ) : (
              <p className="text-lg font-mono">{record.model?.model_no || '-'}</p>
            )}
          </div>
          <div>
            <label className="text-xs font-bold text-gray-500 uppercase">Device SN</label>
            {editMode ? (
              <input value={editData.device_sn || ''} onChange={(e) => setEditData({ ...editData, device_sn: e.target.value })} className="w-full mt-1 px-3 py-2 font-mono" />
            ) : (
              <p className="text-lg font-mono">{record.device_sn}</p>
            )}
          </div>
          <div>
            <label className="text-xs font-bold text-gray-500 uppercase">Status</label>
            {editMode ? (
              <select value={editData.status || ''} onChange={(e) => setEditData({ ...editData, status: e.target.value })} className="w-full mt-1 px-3 py-2">
                <option value="PASSED">Passed</option>
                <option value="DEFECTIVE">Defective</option>
                <option value="REPAIR_PENDING">Repair Pending</option>
                <option value="REPAIR_COMPLETED">Repair Completed</option>
              </select>
            ) : (
              <div className="mt-1">
                {statusConfig && (
                  <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-bold ${statusConfig.bg} bg-opacity-20 ${statusConfig.text}`}>
                    <span className={`w-2.5 h-2.5 rounded-full ${statusConfig.bg}`} />
                    {statusConfig.label}
                  </span>
                )}
              </div>
            )}
          </div>
          <div>
            <label className="text-xs font-bold text-gray-500 uppercase">WO Number</label>
            {editMode ? (
              <input value={editData.wo_number || ''} onChange={(e) => setEditData({ ...editData, wo_number: e.target.value })} className="w-full mt-1 px-3 py-2 font-mono" />
            ) : (
              <p className="text-lg font-mono">{record.wo_number || '-'}</p>
            )}
          </div>
          <div>
            <label className="text-xs font-bold text-gray-500 uppercase">Date / Time</label>
            <p className="mt-1">{formatDate(record.date)} <span className="text-gray-500">{record.time}</span></p>
          </div>
          <div>
            <label className="text-xs font-bold text-gray-500 uppercase">Technician</label>
            <p className="mt-1 font-medium">{record.technician?.technician_name || '-'}</p>
          </div>
        </div>
      </div>

      {/* Defect Info */}
      {(record.status !== 'PASSED' || editMode) && (
        <div className="bg-white dark:bg-neox-card rounded-xl border border-gray-200 dark:border-gray-800 p-6 space-y-4">
          <h3 className="text-lg font-bold border-b border-gray-200 dark:border-gray-800 pb-2">Defect Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase">Reason</label>
              {editMode ? (
                <textarea value={editData.reason_for_replacement || ''} onChange={(e) => setEditData({ ...editData, reason_for_replacement: e.target.value })} className="w-full mt-1 px-3 py-2" rows={3} />
              ) : (
                <p className="mt-1">{record.reason_for_replacement || '-'}</p>
              )}
            </div>
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase">Defect Location</label>
              {editMode ? (
                <select value={editData.defect_location_id || ''} onChange={(e) => setEditData({ ...editData, defect_location_id: e.target.value })} className="w-full mt-1 px-3 py-2">
                  <option value="">Select...</option>
                  {defectLocations.map((d) => <option key={d.id} value={d.id}>{d.location_name}</option>)}
                </select>
              ) : (
                <p className="mt-1">{record.defect_location?.location_name || '-'}</p>
              )}
            </div>
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase">Action Taken</label>
              {editMode ? (
                <select value={editData.action_taken || ''} onChange={(e) => setEditData({ ...editData, action_taken: e.target.value })} className="w-full mt-1 px-3 py-2">
                  <option value="">Select...</option>
                  {['Repaired','Replaced','Adjusted','Reassembled','Sent to Assembly','Sent to Maintenance','Replaced Part','Other'].map(a => <option key={a} value={a}>{a}</option>)}
                </select>
              ) : (
                <p className="mt-1">{record.action_taken || '-'}</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Photos */}
      <div className="bg-white dark:bg-neox-card rounded-xl border border-gray-200 dark:border-gray-800 p-6">
        <h3 className="text-lg font-bold border-b border-gray-200 dark:border-gray-800 pb-2 mb-4">Photos</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <p className="text-sm font-bold text-gray-500 uppercase mb-2">Photo BEFORE</p>
            {record.photo_before_url ? (
              <img
                src={record.photo_before_url}
                alt="Before"
                className="w-full h-64 object-cover rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                onClick={() => setPhotoModal(record.photo_before_url)}
              />
            ) : (
              <div className="w-full h-64 bg-gray-100 dark:bg-gray-800 rounded-lg flex flex-col items-center justify-center text-gray-400">
                <ImageOff className="w-12 h-12 mb-2" />
                <span className="text-sm">No photo</span>
              </div>
            )}
          </div>
          <div>
            <p className="text-sm font-bold text-gray-500 uppercase mb-2">Photo AFTER</p>
            {record.photo_after_url ? (
              <img
                src={record.photo_after_url}
                alt="After"
                className="w-full h-64 object-cover rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                onClick={() => setPhotoModal(record.photo_after_url)}
              />
            ) : (
              <div className="w-full h-64 bg-gray-100 dark:bg-gray-800 rounded-lg flex flex-col items-center justify-center text-gray-400">
                <ImageOff className="w-12 h-12 mb-2" />
                <span className="text-sm">No photo</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Photo Modal */}
      {photoModal && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4" onClick={() => setPhotoModal(null)}>
          <button className="absolute top-4 right-4 text-white p-2"><X className="w-8 h-8" /></button>
          <img src={photoModal} alt="Full size" className="max-w-full max-h-[90vh] object-contain rounded-lg" />
        </div>
      )}
    </div>
  );
}
