-- ============================================================
-- NEOX FALCO QC SYSTEM — PRODUCTION-READY MIGRATION
-- Includes: RLS, Image Storage, FK Relations, Triggers, Roles
-- ============================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. ENUMS
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'app_role') THEN
        CREATE TYPE app_role AS ENUM ('Admin', 'QC', 'Production', 'Maintenance', 'Warehouse', 'Viewer');
    END IF;
END$$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'record_status') THEN
        CREATE TYPE record_status AS ENUM ('PASSED', 'DEFECTIVE', 'REPAIR_PENDING', 'REPAIR_COMPLETED');
    END IF;
END$$;

-- 3. USERS / TECHNICIANS TABLE
CREATE TABLE IF NOT EXISTS technicians (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  technician_name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  role app_role NOT NULL DEFAULT 'Viewer',
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. DEVICES TABLE
CREATE TABLE IF NOT EXISTS devices (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  device_sn TEXT NOT NULL UNIQUE,
  model_no TEXT NOT NULL,
  model_name TEXT,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. MODELS TABLE
CREATE TABLE IF NOT EXISTS models (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  model_no TEXT NOT NULL UNIQUE,
  model_name TEXT,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. DEFECT LOCATIONS TABLE
CREATE TABLE IF NOT EXISTS defect_locations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  location_name TEXT NOT NULL UNIQUE,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. PRODUCTION RECORDS TABLE
CREATE TABLE IF NOT EXISTS production_records (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  time TIME NOT NULL DEFAULT CURRENT_TIME,
  model_id UUID REFERENCES models(id) ON DELETE SET NULL,
  device_id UUID REFERENCES devices(id) ON DELETE SET NULL,
  device_sn TEXT NOT NULL,
  status record_status NOT NULL DEFAULT 'PASSED',
  reason_for_replacement TEXT,
  defect_location_id UUID REFERENCES defect_locations(id) ON DELETE SET NULL,
  photo_before_url TEXT,
  photo_after_url TEXT,
  action_taken TEXT,
  wo_number TEXT UNIQUE,
  technician_id UUID REFERENCES technicians(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. DEFECTS TABLE (Detailed defect tracking)
CREATE TABLE IF NOT EXISTS defects (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  production_record_id UUID NOT NULL REFERENCES production_records(id) ON DELETE CASCADE,
  device_id UUID REFERENCES devices(id) ON DELETE SET NULL,
  defect_type TEXT NOT NULL,
  defect_location_id UUID REFERENCES defect_locations(id) ON DELETE SET NULL,
  severity TEXT CHECK (severity IN ('Low', 'Medium', 'High', 'Critical')),
  description TEXT,
  technician_id UUID REFERENCES technicians(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. RECORD IMAGES TABLE (Linked to defects with CASCADE)
CREATE TABLE IF NOT EXISTS record_images (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  production_record_id UUID REFERENCES production_records(id) ON DELETE CASCADE,
  defect_id UUID REFERENCES defects(id) ON DELETE CASCADE,
  image_url TEXT NOT NULL,
  image_type TEXT CHECK (image_type IN ('BEFORE', 'AFTER', 'DOCUMENT')),
  storage_path TEXT NOT NULL,
  uploaded_by UUID REFERENCES technicians(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. WORK ORDERS TABLE
CREATE TABLE IF NOT EXISTS work_orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  wo_number TEXT NOT NULL UNIQUE,
  device_id UUID REFERENCES devices(id) ON DELETE SET NULL,
  production_record_id UUID REFERENCES production_records(id) ON DELETE SET NULL,
  assigned_to UUID REFERENCES technicians(id) ON DELETE SET NULL,
  status TEXT CHECK (status IN ('OPEN', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED')) DEFAULT 'OPEN',
  priority TEXT CHECK (priority IN ('LOW', 'NORMAL', 'HIGH', 'URGENT')) DEFAULT 'NORMAL',
  description TEXT,
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  created_by UUID REFERENCES technicians(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. MAINTENANCE LOGS TABLE
CREATE TABLE IF NOT EXISTS maintenance_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  work_order_id UUID REFERENCES work_orders(id) ON DELETE SET NULL,
  device_id UUID REFERENCES devices(id) ON DELETE SET NULL,
  action_taken TEXT NOT NULL,
  notes TEXT,
  technician_id UUID REFERENCES technicians(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 12. WO SEQUENCES TABLE
CREATE TABLE IF NOT EXISTS wo_sequences (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  prefix TEXT NOT NULL DEFAULT 'P-G25B002N',
  current_number INTEGER NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 13. AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES technicians(id) ON DELETE SET NULL,
  action TEXT NOT NULL CHECK (action IN ('CREATE', 'UPDATE', 'DELETE', 'LOGIN', 'LOGOUT')),
  record_id UUID,
  table_name TEXT NOT NULL,
  old_value JSONB,
  new_value JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- INDEXES (Performance)
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_records_date ON production_records(date);
CREATE INDEX IF NOT EXISTS idx_records_status ON production_records(status);
CREATE INDEX IF NOT EXISTS idx_records_sn ON production_records(device_sn);
CREATE INDEX IF NOT EXISTS idx_records_wo ON production_records(wo_number);
CREATE INDEX IF NOT EXISTS idx_records_model ON production_records(model_id);
CREATE INDEX IF NOT EXISTS idx_records_technician ON production_records(technician_id);
CREATE INDEX IF NOT EXISTS idx_records_device ON production_records(device_id);
CREATE INDEX IF NOT EXISTS idx_defects_record ON defects(production_record_id);
CREATE INDEX IF NOT EXISTS idx_images_record ON record_images(production_record_id);
CREATE INDEX IF NOT EXISTS idx_images_defect ON record_images(defect_id);
CREATE INDEX IF NOT EXISTS idx_work_orders_number ON work_orders(wo_number);
CREATE INDEX IF NOT EXISTS idx_work_orders_device ON work_orders(device_id);
CREATE INDEX IF NOT EXISTS idx_maintenance_wo ON maintenance_logs(work_order_id);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_record ON audit_logs(record_id);

-- Unique constraint: one SN per day
CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_sn_per_day ON production_records(device_sn, date);

-- ============================================================
-- FUNCTIONS
-- ============================================================

-- Safe WO Number Generator (prevents duplicates)
CREATE OR REPLACE FUNCTION generate_wo_number()
RETURNS TEXT AS $$
DECLARE
  new_number INTEGER;
  prefix TEXT;
  result TEXT;
BEGIN
  SELECT wo_sequences.prefix, wo_sequences.current_number
  INTO prefix, new_number
  FROM wo_sequences
  WHERE id = (SELECT id FROM wo_sequences LIMIT 1)
  FOR UPDATE;

  new_number := new_number + 1;

  UPDATE wo_sequences
  SET current_number = new_number, updated_at = NOW()
  WHERE id = (SELECT id FROM wo_sequences LIMIT 1);

  result := prefix || '-' || new_number || '-1';
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Safe updated_at trigger (NO infinite loops)
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Audit log trigger (safe, no recursion)
CREATE OR REPLACE FUNCTION audit_trigger_fn()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO audit_logs (user_id, action, record_id, table_name, new_value)
    VALUES (auth.uid(), 'CREATE', NEW.id, TG_TABLE_NAME, to_jsonb(NEW));
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    INSERT INTO audit_logs (user_id, action, record_id, table_name, old_value, new_value)
    VALUES (auth.uid(), 'UPDATE', NEW.id, TG_TABLE_NAME, to_jsonb(OLD), to_jsonb(NEW));
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    INSERT INTO audit_logs (user_id, action, record_id, table_name, old_value)
    VALUES (auth.uid(), 'DELETE', OLD.id, TG_TABLE_NAME, to_jsonb(OLD));
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- TRIGGERS (updated_at only — safe, no infinite loops)
-- ============================================================
DROP TRIGGER IF EXISTS trg_technicians_updated_at ON technicians;
CREATE TRIGGER trg_technicians_updated_at BEFORE UPDATE ON technicians
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS trg_models_updated_at ON models;
CREATE TRIGGER trg_models_updated_at BEFORE UPDATE ON models
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS trg_devices_updated_at ON devices;
CREATE TRIGGER trg_devices_updated_at BEFORE UPDATE ON devices
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS trg_records_updated_at ON production_records;
CREATE TRIGGER trg_records_updated_at BEFORE UPDATE ON production_records
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS trg_defects_updated_at ON defects;
CREATE TRIGGER trg_defects_updated_at BEFORE UPDATE ON defects
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS trg_work_orders_updated_at ON work_orders;
CREATE TRIGGER trg_work_orders_updated_at BEFORE UPDATE ON work_orders
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS trg_maintenance_updated_at ON maintenance_logs;
CREATE TRIGGER trg_maintenance_updated_at BEFORE UPDATE ON maintenance_logs
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Audit triggers (only on main tables)
DROP TRIGGER IF EXISTS trg_audit_production_records ON production_records;
CREATE TRIGGER trg_audit_production_records
  AFTER INSERT OR UPDATE OR DELETE ON production_records
  FOR EACH ROW EXECUTE FUNCTION audit_trigger_fn();

DROP TRIGGER IF EXISTS trg_audit_defects ON defects;
CREATE TRIGGER trg_audit_defects
  AFTER INSERT OR UPDATE OR DELETE ON defects
  FOR EACH ROW EXECUTE FUNCTION audit_trigger_fn();

DROP TRIGGER IF EXISTS trg_audit_work_orders ON work_orders;
CREATE TRIGGER trg_audit_work_orders
  AFTER INSERT OR UPDATE OR DELETE ON work_orders
  FOR EACH ROW EXECUTE FUNCTION audit_trigger_fn();

-- ============================================================
-- ROW LEVEL SECURITY (RLS) — PRODUCTION-READY
-- ============================================================

ALTER TABLE technicians ENABLE ROW LEVEL SECURITY;
ALTER TABLE devices ENABLE ROW LEVEL SECURITY;
ALTER TABLE models ENABLE ROW LEVEL SECURITY;
ALTER TABLE defect_locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE production_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE defects ENABLE ROW LEVEL SECURITY;
ALTER TABLE record_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE work_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE maintenance_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE wo_sequences ENABLE ROW LEVEL SECURITY;

-- Helper: check if user has allowed role
CREATE OR REPLACE FUNCTION is_authorized_role(allowed_roles app_role[])
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM technicians
    WHERE id = auth.uid() AND role = ANY(allowed_roles) AND active = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Helper: check if user is Admin
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM technicians WHERE id = auth.uid() AND role = 'Admin' AND active = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- TECHNICIANS (Users)
CREATE POLICY "tech_select_all" ON technicians FOR SELECT TO authenticated USING (true);
CREATE POLICY "tech_insert_admin" ON technicians FOR INSERT TO authenticated WITH CHECK (is_admin());
CREATE POLICY "tech_update_admin" ON technicians FOR UPDATE TO authenticated USING (is_admin());
CREATE POLICY "tech_delete_admin" ON technicians FOR DELETE TO authenticated USING (is_admin());

-- DEVICES
CREATE POLICY "devices_select_all" ON devices FOR SELECT TO authenticated USING (true);
CREATE POLICY "devices_insert_auth" ON devices FOR INSERT TO authenticated WITH CHECK (
  is_authorized_role(ARRAY['Admin'::app_role, 'QC'::app_role, 'Production'::app_role])
);
CREATE POLICY "devices_update_auth" ON devices FOR UPDATE TO authenticated USING (
  is_authorized_role(ARRAY['Admin'::app_role, 'QC'::app_role, 'Production'::app_role])
);
CREATE POLICY "devices_delete_admin" ON devices FOR DELETE TO authenticated USING (is_admin());

-- MODELS
CREATE POLICY "models_select_all" ON models FOR SELECT TO authenticated USING (true);
CREATE POLICY "models_insert_auth" ON models FOR INSERT TO authenticated WITH CHECK (
  is_authorized_role(ARRAY['Admin'::app_role, 'QC'::app_role, 'Production'::app_role])
);
CREATE POLICY "models_update_auth" ON models FOR UPDATE TO authenticated USING (
  is_authorized_role(ARRAY['Admin'::app_role, 'QC'::app_role, 'Production'::app_role])
);
CREATE POLICY "models_delete_admin" ON models FOR DELETE TO authenticated USING (is_admin());

-- DEFECT LOCATIONS
CREATE POLICY "loc_select_all" ON defect_locations FOR SELECT TO authenticated USING (true);
CREATE POLICY "loc_insert_auth" ON defect_locations FOR INSERT TO authenticated WITH CHECK (
  is_authorized_role(ARRAY['Admin'::app_role, 'QC'::app_role, 'Production'::app_role])
);
CREATE POLICY "loc_update_auth" ON defect_locations FOR UPDATE TO authenticated USING (
  is_authorized_role(ARRAY['Admin'::app_role, 'QC'::app_role, 'Production'::app_role])
);
CREATE POLICY "loc_delete_admin" ON defect_locations FOR DELETE TO authenticated USING (is_admin());

-- PRODUCTION RECORDS
-- Read: all authenticated
CREATE POLICY "rec_select_all" ON production_records FOR SELECT TO authenticated USING (true);
-- Insert: QC, Production, Maintenance, Admin
CREATE POLICY "rec_insert_auth" ON production_records FOR INSERT TO authenticated WITH CHECK (
  is_authorized_role(ARRAY['Admin'::app_role, 'QC'::app_role, 'Production'::app_role, 'Maintenance'::app_role])
);
-- Update: QC, Production, Maintenance, Admin (or own record)
CREATE POLICY "rec_update_auth" ON production_records FOR UPDATE TO authenticated USING (
  is_authorized_role(ARRAY['Admin'::app_role, 'QC'::app_role, 'Production'::app_role, 'Maintenance'::app_role])
  OR technician_id = auth.uid()
);
-- Delete: Admin ONLY
CREATE POLICY "rec_delete_admin" ON production_records FOR DELETE TO authenticated USING (is_admin());

-- DEFECTS
CREATE POLICY "def_select_all" ON defects FOR SELECT TO authenticated USING (true);
CREATE POLICY "def_insert_auth" ON defects FOR INSERT TO authenticated WITH CHECK (
  is_authorized_role(ARRAY['Admin'::app_role, 'QC'::app_role, 'Production'::app_role, 'Maintenance'::app_role])
);
CREATE POLICY "def_update_auth" ON defects FOR UPDATE TO authenticated USING (
  is_authorized_role(ARRAY['Admin'::app_role, 'QC'::app_role, 'Production'::app_role, 'Maintenance'::app_role])
);
CREATE POLICY "def_delete_admin" ON defects FOR DELETE TO authenticated USING (is_admin());

-- RECORD IMAGES
CREATE POLICY "img_select_all" ON record_images FOR SELECT TO authenticated USING (true);
CREATE POLICY "img_insert_auth" ON record_images FOR INSERT TO authenticated WITH CHECK (
  is_authorized_role(ARRAY['Admin'::app_role, 'QC'::app_role, 'Production'::app_role, 'Maintenance'::app_role])
);
CREATE POLICY "img_delete_admin" ON record_images FOR DELETE TO authenticated USING (is_admin());

-- WORK ORDERS
CREATE POLICY "wo_select_all" ON work_orders FOR SELECT TO authenticated USING (true);
CREATE POLICY "wo_insert_auth" ON work_orders FOR INSERT TO authenticated WITH CHECK (
  is_authorized_role(ARRAY['Admin'::app_role, 'QC'::app_role, 'Production'::app_role, 'Maintenance'::app_role])
);
CREATE POLICY "wo_update_auth" ON work_orders FOR UPDATE TO authenticated USING (
  is_authorized_role(ARRAY['Admin'::app_role, 'QC'::app_role, 'Production'::app_role, 'Maintenance'::app_role])
  OR assigned_to = auth.uid()
);
CREATE POLICY "wo_delete_admin" ON work_orders FOR DELETE TO authenticated USING (is_admin());

-- MAINTENANCE LOGS
CREATE POLICY "maint_select_all" ON maintenance_logs FOR SELECT TO authenticated USING (true);
CREATE POLICY "maint_insert_auth" ON maintenance_logs FOR INSERT TO authenticated WITH CHECK (
  is_authorized_role(ARRAY['Admin'::app_role, 'Maintenance'::app_role, 'QC'::app_role])
);
CREATE POLICY "maint_update_auth" ON maintenance_logs FOR UPDATE TO authenticated USING (
  is_authorized_role(ARRAY['Admin'::app_role, 'Maintenance'::app_role, 'QC'::app_role])
);
CREATE POLICY "maint_delete_admin" ON maintenance_logs FOR DELETE TO authenticated USING (is_admin());

-- AUDIT LOGS (Admin only)
CREATE POLICY "audit_select_admin" ON audit_logs FOR SELECT TO authenticated USING (is_admin());

-- WO SEQUENCES
CREATE POLICY "wo_seq_select_all" ON wo_sequences FOR SELECT TO authenticated USING (true);
CREATE POLICY "wo_seq_update_admin" ON wo_sequences FOR UPDATE TO authenticated USING (is_admin());

-- ============================================================
-- STORAGE BUCKET SETUP (Run in Supabase Dashboard SQL or UI)
-- ============================================================
-- Note: Create bucket "qc-defect-images" via Supabase UI
-- Then apply these policies:

-- INSERT policy for authenticated users with authorized roles
-- SELECT policy for all authenticated users

-- ============================================================
-- SEED DATA
-- ============================================================
INSERT INTO models (model_no, model_name) VALUES
  ('7326', 'NX4148'),
  ('7946', 'NXR382')
ON CONFLICT (model_no) DO NOTHING;

INSERT INTO defect_locations (location_name) VALUES
  ('Rear Cover'),
  ('Bottom Edge'),
  ('Front Panel'),
  ('Inner Box'),
  ('Top Cover'),
  ('Side Panel'),
  ('Door'),
  ('Handle'),
  ('Display Panel'),
  ('Packaging'),
  ('Other')
ON CONFLICT (location_name) DO NOTHING;

INSERT INTO wo_sequences (prefix, current_number) VALUES
  ('P-G25B002N', 0)
ON CONFLICT DO NOTHING;
