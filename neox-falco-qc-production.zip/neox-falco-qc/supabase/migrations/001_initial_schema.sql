-- NEOX FALCO QC System — Supabase Database Schema
-- Run this in Supabase SQL Editor

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Technicians / Users table (extends auth.users)
CREATE TABLE technicians (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  technician_name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK (role IN ('TECHNICIAN', 'QC_SUPERVISOR', 'ADMIN')),
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Models table
CREATE TABLE models (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  model_no TEXT NOT NULL UNIQUE,
  model_name TEXT,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Defect Locations table
CREATE TABLE defect_locations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  location_name TEXT NOT NULL UNIQUE,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- WO Sequences table
CREATE TABLE wo_sequences (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  prefix TEXT NOT NULL DEFAULT 'P-G25B002N',
  current_number INTEGER NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Production Records table
CREATE TABLE production_records (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  time TIME NOT NULL DEFAULT CURRENT_TIME,
  model_id UUID REFERENCES models(id),
  device_sn TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('PASSED', 'DEFECTIVE', 'REPAIR_PENDING', 'REPAIR_COMPLETED')),
  reason_for_replacement TEXT,
  defect_location_id UUID REFERENCES defect_locations(id),
  photo_before_url TEXT,
  photo_after_url TEXT,
  action_taken TEXT,
  wo_number TEXT UNIQUE,
  technician_id UUID REFERENCES technicians(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Audit Logs table
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES technicians(id),
  action TEXT NOT NULL CHECK (action IN ('CREATE', 'UPDATE', 'DELETE')),
  record_id UUID,
  table_name TEXT NOT NULL,
  old_value JSONB,
  new_value JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX idx_records_date ON production_records(date);
CREATE INDEX idx_records_status ON production_records(status);
CREATE INDEX idx_records_sn ON production_records(device_sn);
CREATE INDEX idx_records_wo ON production_records(wo_number);
CREATE INDEX idx_records_model ON production_records(model_id);
CREATE INDEX idx_records_technician ON production_records(technician_id);
CREATE INDEX idx_audit_user ON audit_logs(user_id);
CREATE INDEX idx_audit_record ON audit_logs(record_id);

-- Unique constraint for device SN per day (prevent duplicates)
CREATE UNIQUE INDEX idx_unique_sn_per_day ON production_records(device_sn, date);

-- Function to generate WO number safely
CREATE OR REPLACE FUNCTION generate_wo_number()
RETURNS TEXT AS $$
DECLARE
  new_number INTEGER;
  prefix TEXT;
  result TEXT;
BEGIN
  -- Lock the row to prevent concurrent access
  SELECT wo_sequences.prefix, wo_sequences.current_number
  INTO prefix, new_number
  FROM wo_sequences
  WHERE id = (SELECT id FROM wo_sequences LIMIT 1)
  FOR UPDATE;

  new_number := new_number + 1;

  UPDATE wo_sequences
  SET current_number = new_number, updated_at = NOW()
  WHERE id = (SELECT id FROM wo_sequences LIMIT 1);

  result := prefix || '-' || new_number || '-1';
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Function to auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for updated_at
CREATE TRIGGER update_technicians_updated_at BEFORE UPDATE ON technicians
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_models_updated_at BEFORE UPDATE ON models
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_records_updated_at BEFORE UPDATE ON production_records
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Trigger for audit log on production_records
CREATE OR REPLACE FUNCTION audit_production_records()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO audit_logs (user_id, action, record_id, table_name, new_value)
    VALUES (auth.uid(), 'CREATE', NEW.id, 'production_records', row_to_json(NEW));
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    INSERT INTO audit_logs (user_id, action, record_id, table_name, old_value, new_value)
    VALUES (auth.uid(), 'UPDATE', NEW.id, 'production_records', row_to_json(OLD), row_to_json(NEW));
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    INSERT INTO audit_logs (user_id, action, record_id, table_name, old_value)
    VALUES (auth.uid(), 'DELETE', OLD.id, 'production_records', row_to_json(OLD));
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER production_records_audit
  AFTER INSERT OR UPDATE OR DELETE ON production_records
  FOR EACH ROW EXECUTE FUNCTION audit_production_records();

-- Row Level Security Policies
ALTER TABLE technicians ENABLE ROW LEVEL SECURITY;
ALTER TABLE models ENABLE ROW LEVEL SECURITY;
ALTER TABLE defect_locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE production_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE wo_sequences ENABLE ROW LEVEL SECURITY;

-- Technicians policies
CREATE POLICY "Technicians viewable by authenticated users" ON technicians
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Technicians manageable by admin" ON technicians
  FOR ALL TO authenticated USING (auth.uid() IN (
    SELECT id FROM technicians WHERE role = 'ADMIN'
  ));

-- Models policies
CREATE POLICY "Models viewable by all authenticated" ON models
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Models manageable by supervisor+" ON models
  FOR ALL TO authenticated USING (auth.uid() IN (
    SELECT id FROM technicians WHERE role IN ('QC_SUPERVISOR', 'ADMIN')
  ));

-- Defect locations policies
CREATE POLICY "Defect locations viewable by all" ON defect_locations
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Defect locations manageable by supervisor+" ON defect_locations
  FOR ALL TO authenticated USING (auth.uid() IN (
    SELECT id FROM technicians WHERE role IN ('QC_SUPERVISOR', 'ADMIN')
  ));

-- Production records policies
CREATE POLICY "Records viewable by authenticated" ON production_records
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Records insertable by technician+" ON production_records
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IN (
    SELECT id FROM technicians WHERE role IN ('TECHNICIAN', 'QC_SUPERVISOR', 'ADMIN') AND active = true
  ));
CREATE POLICY "Records editable by supervisor+ or own records" ON production_records
  FOR UPDATE TO authenticated USING (
    auth.uid() IN (SELECT id FROM technicians WHERE role IN ('QC_SUPERVISOR', 'ADMIN'))
    OR technician_id = auth.uid()
  );
CREATE POLICY "Records deletable by supervisor+" ON production_records
  FOR DELETE TO authenticated USING (auth.uid() IN (
    SELECT id FROM technicians WHERE role IN ('QC_SUPERVISOR', 'ADMIN')
  ));

-- Audit logs policies
CREATE POLICY "Audit logs viewable by admin" ON audit_logs
  FOR SELECT TO authenticated USING (auth.uid() IN (
    SELECT id FROM technicians WHERE role = 'ADMIN'
  ));

-- WO sequences policies
CREATE POLICY "WO sequences viewable by authenticated" ON wo_sequences
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "WO sequences manageable by admin" ON wo_sequences
  FOR ALL TO authenticated USING (auth.uid() IN (
    SELECT id FROM technicians WHERE role = 'ADMIN'
  ));

-- Seed Data
INSERT INTO models (model_no, model_name) VALUES
  ('7326', 'NX4148'),
  ('7946', 'NXR382')
ON CONFLICT (model_no) DO NOTHING;

INSERT INTO defect_locations (location_name) VALUES
  ('Rear Cover'),
  ('Bottom Edge'),
  ('Front Panel'),
  ('Inner Box'),
  ('Top Cover'),
  ('Side Panel'),
  ('Door'),
  ('Handle'),
  ('Display Panel'),
  ('Packaging'),
  ('Other')
ON CONFLICT (location_name) DO NOTHING;

INSERT INTO wo_sequences (prefix, current_number) VALUES
  ('P-G25B002N', 0)
ON CONFLICT DO NOTHING;
